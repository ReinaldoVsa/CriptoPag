# ui

Componentes de UI compartilháveis entre `apps/web` e um futuro app com UI
nativa própria. Candidato natural para extrair componentes de
`apps/web/src/components` conforme o design system cresce.

Intencionalmente vazio nesta versão.
