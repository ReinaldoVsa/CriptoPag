# kyc

Reservado para extrair a interface `KycProvider` de
`apps/api/src/modules/kyc`.

Intencionalmente vazio nesta versão — ver `docs/architecture.md`.
