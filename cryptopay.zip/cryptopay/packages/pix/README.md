# pix

Reservado para extrair a interface `PixProvider` de
`apps/api/src/modules/pix`.

Intencionalmente vazio nesta versão — ver `docs/architecture.md`.
