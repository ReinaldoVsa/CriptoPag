# payments

Reservado para extrair a interface `OffRampProvider` de
`apps/api/src/modules/sell-order`.

Intencionalmente vazio nesta versão — ver `docs/architecture.md`.
