# types

Reservado para tipos TypeScript compartilhados entre frontend e backend (ex:
formatos de resposta da API), evitando duplicação manual de interfaces entre
`apps/api` e `apps/web`.

Intencionalmente vazio nesta versão — hoje cada app define seus próprios
tipos localmente.
