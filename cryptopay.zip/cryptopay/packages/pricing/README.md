# pricing

Reservado para extrair a interface `PricingProvider` e adapters de cotação
de `apps/api/src/modules/pricing`.

Intencionalmente vazio nesta versão — ver `docs/architecture.md`.
