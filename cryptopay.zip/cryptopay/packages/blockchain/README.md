# blockchain

Reservado para extrair a interface `BlockchainProvider` e os adapters
(BlockCypher/Alchemy/RPC) de `apps/api/src/modules/wallet` quando/se o
Wallet Service for promovido a serviço separado.

Intencionalmente vazio nesta versão — ver `docs/architecture.md` para a
justificativa de manter a lógica dentro de `apps/api` até que a separação em
serviços seja justificada pelo volume de uso.
