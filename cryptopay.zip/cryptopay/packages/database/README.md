# database

Reservado para o cliente Prisma compartilhado, caso a API seja quebrada em
múltiplos serviços no futuro. Na v1, o Prisma Client vive em `apps/api`
(schema em `apps/api/prisma/schema.prisma`) pois há um único consumidor do
banco.

Intencionalmente vazio nesta versão — ver `docs/architecture.md`.
