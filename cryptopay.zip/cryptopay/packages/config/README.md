# config

Reservado para configuração compartilhada (ex: schemas Zod de validação de
variáveis de ambiente) entre `apps/api` e `apps/web`.

Intencionalmente vazio nesta versão.
