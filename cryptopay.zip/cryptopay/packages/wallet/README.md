# wallet

Reservado para lógica de carteira compartilhável entre backend e um cliente
mobile nativo fora do escopo Capacitor (que reaproveita o HTML/CSS do
Next.js diretamente, sem precisar deste pacote).

Intencionalmente vazio nesta versão.
