import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'br.com.cryptopay.app',
  appName: 'CryptoPay',
  webDir: '../web/out', // gerado por `next build && next export` ou output standalone servido via URL
  server: {
    // Em desenvolvimento, aponte para o Next.js local; em produção, empacote os
    // assets estáticos ou aponte para a URL do Netlify.
    androidScheme: 'https',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: '#0a0a0a',
    },
  },
};

export default config;
