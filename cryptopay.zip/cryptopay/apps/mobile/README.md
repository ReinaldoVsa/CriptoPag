# CryptoPay Mobile (Android via Capacitor)

Este pacote embrulha o frontend Next.js (`apps/web`) em um app Android nativo
usando Capacitor, reaproveitando 100% do código React/Next já construído.

## Passos para gerar o APK/AAB

1. Build do frontend (a versão empacotada, não a de desenvolvimento):
   ```bash
   cd apps/web
   npm run build
   ```
2. Instalar dependências deste pacote:
   ```bash
   cd apps/mobile
   npm install
   ```
3. Adicionar a plataforma Android (gera a pasta `android/`, não versionada por
   conter artefatos de build):
   ```bash
   npm run add:android
   npm run sync
   ```
4. Abrir no Android Studio para configurar assinatura, ícone, splash e
   compilar o APK/AAB:
   ```bash
   npm run open:android
   ```

## Requisitos de infraestrutura nativa

- **Câmera**: usada pelo leitor de QR Code (`@capacitor/camera` + permissão
  `android.permission.CAMERA` no `AndroidManifest.xml`, adicionada
  automaticamente pelo plugin).
- **Deep Links**: configurar `intent-filter` no `AndroidManifest.xml` para
  abrir URIs `cryptopay://` (ex: retorno de WalletConnect) — deve ser feito
  manualmente no projeto Android gerado, pois depende do domínio final.
- **Push Notifications**: requer projeto Firebase (FCM) configurado e
  `google-services.json` no diretório `android/app/` — não incluído aqui
  por depender de credenciais reais do projeto do usuário.
- **WalletConnect**: funciona via deep link/redirect para os apps de carteira
  instalados no dispositivo (ex: qualquer carteira compatível com
  WalletConnect v2).

Nenhum keystore de assinatura de produção está incluído neste repositório —
gere o seu no Android Studio e nunca o versione (já coberto pelo `.gitignore`
raiz: `*.keystore`).
