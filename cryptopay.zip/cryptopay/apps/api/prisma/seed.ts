import { PrismaClient, IntegrationCategory, IntegrationEnvironment, UserRole } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  // Super admin de exemplo (senha deve ser trocada imediatamente em produção)
  const passwordHash = await bcrypt.hash('ChangeMe123!', 12);

  await prisma.user.upsert({
    where: { email: 'admin@cryptopay.com.br' },
    update: {},
    create: {
      email: 'admin@cryptopay.com.br',
      passwordHash,
      cpf: '00000000000',
      fullName: 'CryptoPay Admin',
      birthDate: new Date('1990-01-01'),
      role: UserRole.SUPER_ADMIN,
      termsAcceptedAt: new Date(),
      privacyAcceptedAt: new Date(),
      emailVerifiedAt: new Date(),
    },
  });

  // Integrações placeholder (sem credenciais reais, todas inativas por padrão)
  const integrations: Array<{ category: IntegrationCategory; name: string }> = [
    { category: IntegrationCategory.BLOCKCHAIN, name: 'BlockCypher' },
    { category: IntegrationCategory.BLOCKCHAIN, name: 'Alchemy' },
    { category: IntegrationCategory.BLOCKCHAIN, name: 'RPC' },
    { category: IntegrationCategory.WALLET, name: 'WalletConnect' },
    { category: IntegrationCategory.PRICING, name: 'Market Provider' },
    { category: IntegrationCategory.OFFRAMP, name: 'Off-Ramp Partner' },
    { category: IntegrationCategory.PIX, name: 'PSP Institution' },
    { category: IntegrationCategory.KYC, name: 'KYC Provider' },
  ];

  for (const integration of integrations) {
    await prisma.integration.upsert({
      where: {
        category_name_environment: {
          category: integration.category,
          name: integration.name,
          environment: IntegrationEnvironment.SANDBOX,
        },
      },
      update: {},
      create: {
        category: integration.category,
        name: integration.name,
        environment: IntegrationEnvironment.SANDBOX,
        isActive: false,
        hasSecret: false,
      },
    });
  }

  console.log('Seed concluído. Usuário admin: admin@cryptopay.com.br / ChangeMe123! (trocar imediatamente)');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
