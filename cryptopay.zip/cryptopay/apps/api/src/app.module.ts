import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';
import { APP_GUARD } from '@nestjs/core';
import { PrismaModule } from './prisma/prisma.module';
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { WalletModule } from './modules/wallet/wallet.module';
import { PricingModule } from './modules/pricing/pricing.module';
import { QuoteModule } from './modules/quote/quote.module';
import { SellOrderModule } from './modules/sell-order/sell-order.module';
import { PixModule } from './modules/pix/pix.module';
import { KycModule } from './modules/kyc/kyc.module';
import { WebhooksModule } from './modules/webhooks/webhooks.module';
import { AdminModule } from './modules/admin/admin.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { AuditModule } from './modules/audit/audit.module';
import { IndexerModule } from './modules/indexer/indexer.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ScheduleModule.forRoot(), // habilita @Interval/@Cron (usado pelo IndexerModule)
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 100 }]), // rate limit global; endpoints sensíveis têm limites próprios
    PrismaModule,
    AuditModule,
    HealthModule,
    AuthModule,
    UsersModule,
    WalletModule,
    PricingModule,
    QuoteModule,
    SellOrderModule,
    PixModule,
    KycModule,
    WebhooksModule,
    AdminModule,
    NotificationsModule,
    IndexerModule,
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }],
})
export class AppModule {}
