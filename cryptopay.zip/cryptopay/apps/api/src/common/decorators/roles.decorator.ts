import { SetMetadata } from '@nestjs/common';

export const ROLES_KEY = 'roles';
/** Marca um endpoint com os papéis (RBAC) que podem acessá-lo. Ex: @Roles('ADMIN','SUPER_ADMIN') */
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);
