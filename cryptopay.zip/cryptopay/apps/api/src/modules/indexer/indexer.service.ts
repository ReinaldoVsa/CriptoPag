import { Injectable, Logger } from '@nestjs/common';
import { Interval } from '@nestjs/schedule';
import { WalletService } from '../wallet/wallet.service';
import { SellOrderService } from '../sell-order/sell-order.service';

/**
 * Número mínimo de confirmações on-chain exigido antes de considerar uma
 * transação definitivamente confirmada, por rede. Bitcoin exige mais
 * confirmações (blocos mais lentos, maior risco de reorg) do que redes EVM.
 * Configurável via .env para permitir valores mais baixos em sandbox/teste.
 */
const DEFAULT_REQUIRED_CONFIRMATIONS: Record<string, number> = {
  BITCOIN: 3,
  ETHEREUM: 12,
  POLYGON: 30,
  BSC: 15,
  ARBITRUM: 20,
};

const POLL_INTERVAL_MS = Number(process.env.INDEXER_POLL_INTERVAL_MS) || 30_000;

/**
 * Worker de indexação de blockchain (seção "O que falta para produção" da
 * arquitetura). Faz polling periódico das ordens de venda com transação
 * transmitida (BROADCASTED/CONFIRMING) e consulta a blockchain real para
 * saber quantas confirmações a transação já recebeu — a máquina de estados
 * de SellOrder só avança para CONFIRMED/CONVERTING quando a blockchain,
 * não o frontend, confirma que a transação é definitiva.
 *
 * Implementação via polling simples (@Interval) para não introduzir
 * dependência de infraestrutura de filas nesta fase. Para volume alto de
 * transações simultâneas, considere substituir por:
 *  - um provider de webhooks nativos de confirmação (ex: Alchemy Notify),
 *  - ou uma fila (BullMQ sobre Redis) com jobs agendados por transação,
 * mantendo a mesma interface pública (advanceOnConfirmation).
 */
@Injectable()
export class IndexerService {
  private readonly logger = new Logger(IndexerService.name);
  private isRunning = false;

  constructor(
    private readonly walletService: WalletService,
    private readonly sellOrderService: SellOrderService,
  ) {}

  @Interval(POLL_INTERVAL_MS)
  async pollPendingConfirmations() {
    // Evita sobreposição: se um ciclo anterior ainda está rodando (ex: RPC
    // lento), pula o próximo tick em vez de empilhar consultas concorrentes.
    if (this.isRunning) {
      this.logger.warn('Ciclo anterior do indexer ainda em execução — pulando este tick.');
      return;
    }
    this.isRunning = true;

    try {
      const pending = await this.sellOrderService.listPendingConfirmation();
      if (pending.length === 0) return;

      this.logger.log(`Indexer: verificando ${pending.length} ordem(ns) pendente(s) de confirmação.`);

      for (const order of pending) {
        await this.checkOrder(order);
      }
    } catch (err) {
      this.logger.error('Falha no ciclo do indexer.', (err as Error).stack);
    } finally {
      this.isRunning = false;
    }
  }

  private async checkOrder(order: { id: string; txHash: string | null; wallet: { network: string } }) {
    if (!order.txHash) return;

    const network = order.wallet.network;
    const required = DEFAULT_REQUIRED_CONFIRMATIONS[network] ?? 6;

    try {
      const confirmations = await this.walletService.getTransactionConfirmations(network, order.txHash);
      await this.sellOrderService.advanceOnConfirmation(order.id, confirmations, required);
    } catch (err) {
      // Falha ao consultar a blockchain (ex: RPC fora do ar, credencial
      // ausente) não deve marcar a ordem como FAILED automaticamente —
      // apenas logamos e tentamos de novo no próximo ciclo. Só um erro
      // vindo do próprio off-ramp (dentro de advanceOnConfirmation) deveria
      // eventualmente levar a uma falha definitiva, tratada manualmente
      // via painel admin nesta fase.
      this.logger.warn(
        `Falha ao consultar confirmações da tx ${order.txHash} (${network}): ${(err as Error).message}`,
      );
    }
  }
}
