import { Module } from '@nestjs/common';
import { IndexerService } from './indexer.service';
import { WalletModule } from '../wallet/wallet.module';
import { SellOrderModule } from '../sell-order/sell-order.module';

@Module({
  imports: [WalletModule, SellOrderModule],
  providers: [IndexerService],
})
export class IndexerModule {}
