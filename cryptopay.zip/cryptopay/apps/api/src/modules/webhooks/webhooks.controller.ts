import {
  BadRequestException,
  Body,
  Controller,
  Headers,
  Post,
  Req,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { WebhooksService } from './webhooks.service';

/**
 * Endpoints de webhook (seção 21). Todos validam assinatura, timestamp/origem
 * e idempotência antes de processar qualquer alteração de estado.
 * Nenhum destes endpoints exige autenticação JWT de usuário — a autenticação
 * aqui é feita via assinatura HMAC do parceiro (PIX_WEBHOOK_SECRET, etc).
 */
@ApiTags('webhooks')
@Controller('webhooks')
export class WebhooksController {
  constructor(private readonly webhooksService: WebhooksService) {}

  @Post('pix')
  async pix(
    @Body() body: unknown,
    @Headers('x-signature') signature: string | undefined,
    @Req() req: Request,
  ) {
    if (!signature) throw new BadRequestException('Assinatura ausente.');
    return this.webhooksService.handlePixWebhook(body, signature, req.rawBody?.toString() ?? '');
  }

  @Post('offramp')
  async offramp(
    @Body() body: unknown,
    @Headers('x-signature') signature: string | undefined,
    @Req() req: Request,
  ) {
    if (!signature) throw new BadRequestException('Assinatura ausente.');
    return this.webhooksService.handleOffRampWebhook(body, signature, req.rawBody?.toString() ?? '');
  }

  @Post('kyc')
  async kyc(
    @Body() body: unknown,
    @Headers('x-signature') signature: string | undefined,
    @Req() req: Request,
  ) {
    if (!signature) throw new BadRequestException('Assinatura ausente.');
    return this.webhooksService.handleKycWebhook(body, signature, req.rawBody?.toString() ?? '');
  }
}
