import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import * as crypto from 'crypto';
import { PrismaService } from '../../prisma/prisma.service';
import { SellOrderService } from '../sell-order/sell-order.service';
import { PixService } from '../pix/pix.service';

@Injectable()
export class WebhooksService {
  private readonly logger = new Logger(WebhooksService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly sellOrderService: SellOrderService,
    private readonly pixService: PixService,
  ) {}

  async handlePixWebhook(body: any, signature: string, rawBody: string) {
    const valid = this.pixService.verifyWebhookSignature(rawBody, signature);
    return this.processEvent('PIX', body, valid, async () => {
      const { sellOrderId, status } = this.extractPixEvent(body);
      if (status === 'COMPLETED') {
        await this.sellOrderService.onPixResult(sellOrderId, true);
      } else if (status === 'FAILED') {
        await this.sellOrderService.onPixResult(sellOrderId, false);
      }
    });
  }

  async handleOffRampWebhook(body: any, signature: string, rawBody: string) {
    const valid = this.verifyGenericSignature(rawBody, signature, process.env.OFFRAMP_WEBHOOK_SECRET);
    return this.processEvent('OFFRAMP', body, valid, async () => {
      const { sellOrderId, status } = body ?? {};
      if (status === 'COMPLETED') {
        await this.sellOrderService.onOffRampCompleted(sellOrderId);
      }
    });
  }

  async handleKycWebhook(body: any, signature: string, rawBody: string) {
    const valid = this.verifyGenericSignature(rawBody, signature, process.env.KYC_WEBHOOK_SECRET);
    return this.processEvent('KYC', body, valid, async () => {
      const { verificationId, status, reason } = body ?? {};
      if (verificationId) {
        await this.prisma.kycVerification.update({
          where: { id: verificationId },
          data: { status, reason, reviewedAt: new Date() },
        });
      }
    });
  }

  /**
   * Fluxo comum a todos os webhooks: valida assinatura, checa idempotência
   * (não reprocessa o mesmo evento externo duas vezes) e só então executa
   * a lógica de negócio. Tudo é registrado em WebhookEvent para auditoria.
   */
  private async processEvent(
    source: 'PIX' | 'OFFRAMP' | 'KYC',
    body: any,
    signatureValid: boolean,
    handler: () => Promise<void>,
  ) {
    const externalEventId: string | undefined = body?.eventId ?? body?.id;

    if (externalEventId) {
      const existing = await this.prisma.webhookEvent.findUnique({
        where: { source_externalEventId: { source, externalEventId } },
      });
      if (existing) {
        return { received: true, duplicate: true };
      }
    }

    const event = await this.prisma.webhookEvent.create({
      data: {
        source,
        externalEventId,
        signatureValid,
        payload: body,
        processingStatus: signatureValid ? 'VALIDATED' : 'FAILED',
      },
    });

    if (!signatureValid) {
      this.logger.warn(`Webhook ${source} com assinatura inválida — evento ${event.id} rejeitado.`);
      throw new BadRequestException('Assinatura inválida.');
    }

    try {
      await handler();
      await this.prisma.webhookEvent.update({
        where: { id: event.id },
        data: { processingStatus: 'PROCESSED', processedAt: new Date() },
      });
    } catch (err) {
      await this.prisma.webhookEvent.update({
        where: { id: event.id },
        data: { processingStatus: 'FAILED', errorMessage: (err as Error).message },
      });
      throw err;
    }

    return { received: true };
  }

  private verifyGenericSignature(rawBody: string, signature: string, secret?: string): boolean {
    if (!secret) return false;
    const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    try {
      return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
    } catch {
      return false;
    }
  }

  private extractPixEvent(body: any): { sellOrderId: string; status: string } {
    return { sellOrderId: body?.sellOrderId, status: body?.status };
  }
}
