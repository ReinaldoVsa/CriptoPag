import { Module } from '@nestjs/common';
import { WebhooksController } from './webhooks.controller';
import { WebhooksService } from './webhooks.service';
import { SellOrderModule } from '../sell-order/sell-order.module';
import { PixModule } from '../pix/pix.module';

@Module({
  imports: [SellOrderModule, PixModule],
  controllers: [WebhooksController],
  providers: [WebhooksService],
})
export class WebhooksModule {}
