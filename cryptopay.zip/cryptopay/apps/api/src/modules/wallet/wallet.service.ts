import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { BlockchainProvider } from './blockchain-provider.interface';
import { BlockCypherProvider } from './providers/blockcypher.provider';
import { AlchemyProvider } from './providers/alchemy.provider';
import { RpcProvider } from './providers/rpc.provider';
import { AddWalletDto } from './dto/wallet.dto';
import { AuditService } from '../audit/audit.service';
import { PricingService } from '../pricing/pricing.service';

@Injectable()
export class WalletService {
  private readonly providers: Map<string, BlockchainProvider>;

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly pricing: PricingService,
    private readonly blockCypher: BlockCypherProvider,
    private readonly alchemy: AlchemyProvider,
  ) {
    // Arquitetura de adapters (seção 12): cada rede resolve para um provedor,
    // substituível sem alterar o restante do serviço.
    this.providers = new Map<string, BlockchainProvider>([
      ['BITCOIN', this.blockCypher],
      ['ETHEREUM', this.alchemy],
      ['POLYGON', new RpcProvider('POLYGON', process.env.RPC_URL_POLYGON ?? '')],
      ['BSC', new RpcProvider('BSC', process.env.RPC_URL_BSC ?? '')],
      ['ARBITRUM', new RpcProvider('ARBITRUM', process.env.RPC_URL_ARBITRUM ?? '')],
    ]);
  }

  private resolveProvider(network: string): BlockchainProvider {
    const provider = this.providers.get(network);
    if (!provider) {
      throw new BadRequestException(`Rede não suportada: ${network}`);
    }
    return provider;
  }

  async validateAddress(address: string, network: string): Promise<boolean> {
    return this.resolveProvider(network).validateAddress(address);
  }

  async addWallet(userId: string, dto: AddWalletDto) {
    const isValid = await this.validateAddress(dto.address, dto.network);
    if (!isValid) {
      throw new BadRequestException('Endereço inválido para a rede selecionada.');
    }

    const wallet = await this.prisma.wallet.upsert({
      where: {
        userId_address_network: { userId, address: dto.address, network: dto.network as any },
      },
      update: { label: dto.label, isActive: true },
      create: {
        userId,
        address: dto.address,
        network: dto.network as any,
        label: dto.label,
        source: dto.source,
      },
    });

    await this.audit.log({
      userId,
      action: 'WALLET_ADDED',
      entityType: 'Wallet',
      entityId: wallet.id,
      metadata: { address: dto.address, network: dto.network },
    });

    // IMPORTANTE: apenas o endereço público é salvo. Nunca solicitamos ou
    // armazenamos seed phrase / chave privada (regra fundamental do produto).
    return wallet;
  }

  async listWallets(userId: string) {
    return this.prisma.wallet.findMany({ where: { userId, isActive: true } });
  }

  async getBalance(userId: string, walletId: string) {
    const wallet = await this.prisma.wallet.findFirst({ where: { id: walletId, userId } });
    if (!wallet) throw new NotFoundException('Carteira não encontrada.');

    const provider = this.resolveProvider(wallet.network);
    const [nativeBalance, tokenBalances] = await Promise.all([
      provider.getBalance(wallet.address),
      provider.getTokenBalances(wallet.address),
    ]);

    const price = await this.pricing.getPrice(nativeBalance.asset, 'BRL');
    const estimatedBRL = (parseFloat(nativeBalance.amount) * price.value).toFixed(2);

    // Persiste snapshot do saldo para histórico/cache
    await this.prisma.walletAsset.upsert({
      where: { walletId_assetSymbol: { walletId: wallet.id, assetSymbol: nativeBalance.asset } },
      update: { balance: nativeBalance.amount, lastCheckedAt: new Date() },
      create: {
        walletId: wallet.id,
        assetSymbol: nativeBalance.asset,
        balance: nativeBalance.amount,
      },
    });

    return {
      wallet,
      native: nativeBalance,
      tokens: tokenBalances,
      priceBRL: price.value,
      estimatedBRL,
      priceTimestamp: price.timestamp,
      disclaimer: 'Valor estimado. O valor final da venda pode variar.',
    };
  }

  async getTransactions(userId: string, walletId: string) {
    const wallet = await this.prisma.wallet.findFirst({ where: { id: walletId, userId } });
    if (!wallet) throw new NotFoundException('Carteira não encontrada.');
    const provider = this.resolveProvider(wallet.network);
    return provider.getTransactions(wallet.address);
  }

  /**
   * Consulta o número de confirmações de uma transação diretamente na
   * blockchain, sem exigir contexto de usuário/carteira — usado pelo
   * worker de indexação (IndexerService) para avançar a máquina de
   * estados de SellOrder sem depender de o frontend "avisar" a API.
   */
  async getTransactionConfirmations(network: string, txHash: string): Promise<number> {
    const provider = this.resolveProvider(network);
    const tx = await provider.getTransaction(txHash);
    return tx.confirmations;
  }
}
