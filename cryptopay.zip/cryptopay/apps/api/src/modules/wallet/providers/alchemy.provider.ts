import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import {
  Balance,
  BlockchainProvider,
  BlockchainTransactionInfo,
  TokenBalance,
} from '../blockchain-provider.interface';

/**
 * Adapter real para Alchemy (Ethereum e redes EVM compatíveis).
 * Requer ALCHEMY_API_KEY em .env. Usa os métodos JSON-RPC estendidos da Alchemy
 * (alchemy_getTokenBalances) além do RPC padrão eth_getBalance.
 */
@Injectable()
export class AlchemyProvider implements BlockchainProvider {
  readonly network = 'ETHEREUM';

  private get baseUrl(): string {
    const key = process.env.ALCHEMY_API_KEY;
    if (!key) {
      throw new ServiceUnavailableException(
        'ALCHEMY_API_KEY não configurada. Configure em .env antes de consultar Ethereum/EVM.',
      );
    }
    return `https://eth-mainnet.g.alchemy.com/v2/${key}`;
  }

  async validateAddress(address: string): Promise<boolean> {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  }

  async getBalance(address: string): Promise<Balance> {
    const data = await this.rpcCall('eth_getBalance', [address, 'latest']);
    const weiHex: string = data.result;
    const ethAmount = (Number(BigInt(weiHex)) / 1e18).toFixed(18);
    return { asset: 'ETH', amount: ethAmount, network: this.network };
  }

  async getTokenBalances(address: string): Promise<TokenBalance[]> {
    const data = await this.rpcCall('alchemy_getTokenBalances', [address]);
    const balances = data.result?.tokenBalances ?? [];
    return balances
      .filter((b: any) => b.tokenBalance && b.tokenBalance !== '0x0')
      .map((b: any) => ({
        asset: 'ERC20', // símbolo real exigiria chamada adicional a alchemy_getTokenMetadata
        amount: BigInt(b.tokenBalance).toString(),
        network: this.network,
        contractAddress: b.contractAddress,
      }));
  }

  async getTransactions(address: string): Promise<BlockchainTransactionInfo[]> {
    const data = await this.rpcCall('alchemy_getAssetTransfers', [
      {
        toAddress: address,
        category: ['external', 'erc20'],
        withMetadata: true,
      },
    ]);
    return (data.result?.transfers ?? []).map((t: any) => ({
      txHash: t.hash,
      direction: 'IN' as const,
      asset: t.asset ?? 'ETH',
      amount: String(t.value ?? '0'),
      confirmations: 0,
      confirmedAt: t.metadata?.blockTimestamp ? new Date(t.metadata.blockTimestamp) : undefined,
    }));
  }

  async getTransaction(txHash: string): Promise<BlockchainTransactionInfo> {
    const data = await this.rpcCall('eth_getTransactionByHash', [txHash]);
    const tx = data.result;
    if (!tx) {
      throw new ServiceUnavailableException('Transação não encontrada.');
    }
    return {
      txHash: tx.hash,
      direction: 'IN',
      asset: 'ETH',
      amount: (Number(BigInt(tx.value)) / 1e18).toFixed(18),
      confirmations: 0,
    };
  }

  private async rpcCall(method: string, params: unknown[]) {
    const res = await fetch(this.baseUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
    });
    if (!res.ok) {
      throw new ServiceUnavailableException(`Falha na chamada Alchemy (${method}).`);
    }
    return res.json();
  }
}
