import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import {
  Balance,
  BlockchainProvider,
  BlockchainTransactionInfo,
  TokenBalance,
} from '../blockchain-provider.interface';

const BLOCKCYPHER_BASE_URL = 'https://api.blockcypher.com/v1/btc/main';

/**
 * Adapter real para BlockCypher (Bitcoin mainnet).
 * Requer BLOCKCYPHER_API_KEY configurada em .env — sem a chave, as chamadas
 * falharão explicitamente (nunca simulamos dados de blockchain).
 */
@Injectable()
export class BlockCypherProvider implements BlockchainProvider {
  readonly network = 'BITCOIN';

  private get apiKey(): string {
    const key = process.env.BLOCKCYPHER_API_KEY;
    if (!key) {
      throw new ServiceUnavailableException(
        'BLOCKCYPHER_API_KEY não configurada. Configure em .env antes de consultar Bitcoin.',
      );
    }
    return key;
  }

  async validateAddress(address: string): Promise<boolean> {
    // Validação de formato básica (Base58/Bech32). Validação completa de checksum
    // é feita pela própria API do BlockCypher ao consultar o endereço.
    const btcAddressRegex = /^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/;
    return btcAddressRegex.test(address);
  }

  async getBalance(address: string): Promise<Balance> {
    const url = `${BLOCKCYPHER_BASE_URL}/addrs/${address}/balance?token=${this.apiKey}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new ServiceUnavailableException('Falha ao consultar saldo no BlockCypher.');
    }
    const data = await res.json();
    // BlockCypher retorna balance em satoshis
    const btcAmount = (data.balance / 1e8).toFixed(8);
    return { asset: 'BTC', amount: btcAmount, network: this.network };
  }

  async getTokenBalances(): Promise<TokenBalance[]> {
    // Bitcoin não possui tokens (ao contrário de redes EVM)
    return [];
  }

  async getTransactions(address: string): Promise<BlockchainTransactionInfo[]> {
    const url = `${BLOCKCYPHER_BASE_URL}/addrs/${address}/full?token=${this.apiKey}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new ServiceUnavailableException('Falha ao consultar transações no BlockCypher.');
    }
    const data = await res.json();
    return (data.txs ?? []).map((tx: any) => this.mapTransaction(tx, address));
  }

  async getTransaction(txHash: string): Promise<BlockchainTransactionInfo> {
    const url = `${BLOCKCYPHER_BASE_URL}/txs/${txHash}?token=${this.apiKey}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new ServiceUnavailableException('Transação não encontrada no BlockCypher.');
    }
    const tx = await res.json();
    return this.mapTransaction(tx);
  }

  private mapTransaction(tx: any, address?: string): BlockchainTransactionInfo {
    const direction: 'IN' | 'OUT' =
      address && tx.inputs?.some((i: any) => i.addresses?.includes(address)) ? 'OUT' : 'IN';
    return {
      txHash: tx.hash,
      direction,
      asset: 'BTC',
      amount: (tx.total / 1e8).toFixed(8),
      confirmations: tx.confirmations ?? 0,
      confirmedAt: tx.confirmed ? new Date(tx.confirmed) : undefined,
    };
  }
}
