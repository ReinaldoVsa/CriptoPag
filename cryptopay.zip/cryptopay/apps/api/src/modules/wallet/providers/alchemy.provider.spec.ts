import { AlchemyProvider } from './alchemy.provider';

describe('AlchemyProvider - validateAddress', () => {
  const provider = new AlchemyProvider();

  it('aceita endereço EVM válido', async () => {
    await expect(
      provider.validateAddress('0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48'),
    ).resolves.toBe(true);
  });

  it('rejeita endereço sem prefixo 0x', async () => {
    await expect(
      provider.validateAddress('71C7656EC7ab88b098defB751B7401B5f6d8976'),
    ).resolves.toBe(false);
  });

  it('rejeita endereço com tamanho incorreto', async () => {
    await expect(provider.validateAddress('0x1234')).resolves.toBe(false);
  });
});
