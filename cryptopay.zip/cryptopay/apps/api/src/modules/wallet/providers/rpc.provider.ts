import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import {
  Balance,
  BlockchainProvider,
  BlockchainTransactionInfo,
  TokenBalance,
} from '../blockchain-provider.interface';

/**
 * Adapter para RPC próprio/genérico (ex: Polygon, BSC, Arbitrum via RPC_URL_*).
 * Útil quando não se quer depender de Alchemy/BlockCypher para uma rede específica.
 * Implementa apenas o essencial via JSON-RPC padrão (eth_getBalance).
 */
@Injectable()
export class RpcProvider implements BlockchainProvider {
  readonly network: string;
  private readonly rpcUrl: string;

  constructor(network: string, rpcUrl: string) {
    this.network = network;
    this.rpcUrl = rpcUrl;
  }

  async validateAddress(address: string): Promise<boolean> {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  }

  async getBalance(address: string): Promise<Balance> {
    if (!this.rpcUrl) {
      throw new ServiceUnavailableException(
        `RPC_URL para ${this.network} não configurada em .env.`,
      );
    }
    const res = await fetch(this.rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_getBalance',
        params: [address, 'latest'],
      }),
    });
    if (!res.ok) {
      throw new ServiceUnavailableException(`Falha ao consultar RPC de ${this.network}.`);
    }
    const data = await res.json();
    const amount = (Number(BigInt(data.result)) / 1e18).toFixed(18);
    return { asset: this.network, amount, network: this.network };
  }

  async getTokenBalances(): Promise<TokenBalance[]> {
    // Consulta de tokens via RPC genérico exigiria ABI calls (balanceOf) por contrato;
    // fora do escopo do adapter mínimo. Usar AlchemyProvider quando tokens forem necessários.
    return [];
  }

  async getTransactions(): Promise<BlockchainTransactionInfo[]> {
    return [];
  }

  async getTransaction(txHash: string): Promise<BlockchainTransactionInfo> {
    const res = await fetch(this.rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_getTransactionByHash',
        params: [txHash],
      }),
    });
    const data = await res.json();
    if (!data.result) {
      throw new ServiceUnavailableException('Transação não encontrada.');
    }
    return {
      txHash: data.result.hash,
      direction: 'IN',
      asset: this.network,
      amount: (Number(BigInt(data.result.value)) / 1e18).toFixed(18),
      confirmations: 0,
    };
  }
}
