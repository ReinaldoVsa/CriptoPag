import { BlockCypherProvider } from './blockcypher.provider';

describe('BlockCypherProvider - validateAddress', () => {
  const provider = new BlockCypherProvider();

  it('aceita endereço Bitcoin legado válido (P2PKH)', async () => {
    await expect(
      provider.validateAddress('1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2'),
    ).resolves.toBe(true);
  });

  it('aceita endereço Bitcoin bech32 válido', async () => {
    await expect(
      provider.validateAddress('bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq'),
    ).resolves.toBe(true);
  });

  it('rejeita endereço inválido', async () => {
    await expect(provider.validateAddress('endereco-invalido')).resolves.toBe(false);
  });
});
