import { Module } from '@nestjs/common';
import { WalletController } from './wallet.controller';
import { WalletService } from './wallet.service';
import { BlockCypherProvider } from './providers/blockcypher.provider';
import { AlchemyProvider } from './providers/alchemy.provider';
import { AuditModule } from '../audit/audit.module';
import { PricingModule } from '../pricing/pricing.module';

@Module({
  imports: [AuditModule, PricingModule],
  controllers: [WalletController],
  providers: [WalletService, BlockCypherProvider, AlchemyProvider],
  exports: [WalletService],
})
export class WalletModule {}
