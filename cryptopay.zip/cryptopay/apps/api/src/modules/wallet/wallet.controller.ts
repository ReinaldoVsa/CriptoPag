import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { WalletService } from './wallet.service';
import { addWalletSchema, validateAddressSchema } from './dto/wallet.dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('wallets')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('wallets')
export class WalletController {
  constructor(private readonly walletService: WalletService) {}

  @Post('validate')
  async validate(@Body() body: unknown) {
    const dto = validateAddressSchema.parse(body);
    const isValid = await this.walletService.validateAddress(dto.address, dto.network);
    return { isValid };
  }

  @Post()
  async create(@CurrentUser('id') userId: string, @Body() body: unknown) {
    const dto = addWalletSchema.parse(body);
    return this.walletService.addWallet(userId, dto);
  }

  @Get()
  async list(@CurrentUser('id') userId: string) {
    return this.walletService.listWallets(userId);
  }

  @Get(':id/balance')
  async balance(@CurrentUser('id') userId: string, @Param('id') id: string) {
    return this.walletService.getBalance(userId, id);
  }

  @Get(':id/transactions')
  async transactions(@CurrentUser('id') userId: string, @Param('id') id: string) {
    return this.walletService.getTransactions(userId, id);
  }
}
