import { z } from 'zod';

export const addWalletSchema = z.object({
  address: z.string().min(10).max(100),
  network: z.enum(['BITCOIN', 'ETHEREUM', 'POLYGON', 'BSC', 'ARBITRUM']),
  label: z.string().max(60).optional(),
  source: z.enum(['MANUAL', 'QRCODE', 'WALLETCONNECT']).default('MANUAL'),
});
export type AddWalletDto = z.infer<typeof addWalletSchema>;

export const validateAddressSchema = z.object({
  address: z.string().min(10).max(100),
  network: z.enum(['BITCOIN', 'ETHEREUM', 'POLYGON', 'BSC', 'ARBITRUM']),
});
export type ValidateAddressDto = z.infer<typeof validateAddressSchema>;
