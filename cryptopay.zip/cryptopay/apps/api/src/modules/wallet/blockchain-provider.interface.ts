export interface Balance {
  asset: string;
  amount: string; // string para evitar perda de precisão com valores decimais grandes
  network: string;
}

export interface TokenBalance extends Balance {
  contractAddress?: string;
}

export interface BlockchainTransactionInfo {
  txHash: string;
  direction: 'IN' | 'OUT';
  asset: string;
  amount: string;
  confirmations: number;
  confirmedAt?: Date;
}

/**
 * Contrato comum que todo provedor de blockchain deve implementar.
 * Isso permite trocar BlockCypher <-> Alchemy <-> RPC próprio sem alterar
 * o restante da aplicação (Wallet Service depende apenas desta interface).
 */
export interface BlockchainProvider {
  readonly network: string;

  validateAddress(address: string): Promise<boolean>;
  getBalance(address: string): Promise<Balance>;
  getTokenBalances(address: string): Promise<TokenBalance[]>;
  getTransactions(address: string): Promise<BlockchainTransactionInfo[]>;
  getTransaction(txHash: string): Promise<BlockchainTransactionInfo>;
}

export const BLOCKCHAIN_PROVIDER = Symbol('BLOCKCHAIN_PROVIDER');
