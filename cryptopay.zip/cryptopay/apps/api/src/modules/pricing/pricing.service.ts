import { Injectable } from '@nestjs/common';
import { Price } from './pricing-provider.interface';
import { MarketPricingProvider } from './providers/market.provider';

const CACHE_TTL_MS = 15_000; // 15s: reduz custo de chamadas externas sem ficar defasado

@Injectable()
export class PricingService {
  private cache = new Map<string, { price: Price; expiresAt: number }>();

  constructor(private readonly provider: MarketPricingProvider) {}

  async getPrice(asset: string, currency: string): Promise<Price> {
    const key = `${asset.toUpperCase()}_${currency.toUpperCase()}`;
    const cached = this.cache.get(key);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.price;
    }

    const price = await this.provider.getPrice(asset, currency);
    this.cache.set(key, { price, expiresAt: Date.now() + CACHE_TTL_MS });
    return price;
  }
}
