export interface Price {
  asset: string;
  currency: string;
  value: number;
  source: string;
  timestamp: Date;
}

/**
 * Contrato de provedor de cotação. O backend SEMPRE recalcula o preço no momento
 * da consulta/venda — nunca confia em cotação enviada pelo frontend (seção 14).
 */
export interface PricingProvider {
  getPrice(asset: string, currency: string): Promise<Price>;
}
