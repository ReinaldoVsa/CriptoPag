import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import { Price, PricingProvider } from '../pricing-provider.interface';

const ASSET_ID_MAP: Record<string, string> = {
  BTC: 'bitcoin',
  ETH: 'ethereum',
  POLYGON: 'matic-network',
  BSC: 'binancecoin',
};

/**
 * Adapter de cotação de mercado. Usa a API pública da CoinGecko por padrão
 * (endpoint documentado, sem necessidade de credencial para o plano gratuito).
 * Se PRICING_PROVIDER e PRICING_API_KEY estiverem configurados para outro
 * provedor (ex: um provedor pago com SLA), substitua esta classe mantendo
 * a mesma interface PricingProvider.
 */
@Injectable()
export class MarketPricingProvider implements PricingProvider {
  async getPrice(asset: string, currency: string): Promise<Price> {
    const coinId = ASSET_ID_MAP[asset.toUpperCase()];
    if (!coinId) {
      throw new ServiceUnavailableException(`Ativo sem mapeamento de cotação: ${asset}`);
    }

    const vsCurrency = currency.toLowerCase();
    const url = `https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=${vsCurrency}`;

    const res = await fetch(url);
    if (!res.ok) {
      throw new ServiceUnavailableException('Falha ao consultar cotação.');
    }
    const data = await res.json();
    const value = data?.[coinId]?.[vsCurrency];
    if (value === undefined) {
      throw new ServiceUnavailableException('Cotação indisponível para o par solicitado.');
    }

    return {
      asset: asset.toUpperCase(),
      currency: currency.toUpperCase(),
      value,
      source: 'CoinGecko',
      timestamp: new Date(),
    };
  }
}
