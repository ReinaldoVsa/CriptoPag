import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PricingService } from './pricing.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@ApiTags('pricing')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller()
export class PricingController {
  constructor(private readonly pricingService: PricingService) {}

  @Get('assets')
  listAssets() {
    return [
      { symbol: 'BTC', name: 'Bitcoin', network: 'BITCOIN' },
      { symbol: 'ETH', name: 'Ethereum', network: 'ETHEREUM' },
      { symbol: 'POLYGON', name: 'Polygon', network: 'POLYGON' },
      { symbol: 'BSC', name: 'BNB Smart Chain', network: 'BSC' },
    ];
  }

  @Get('prices/:asset')
  async getPrice(@Param('asset') asset: string, @Query('currency') currency = 'BRL') {
    return this.pricingService.getPrice(asset, currency);
  }
}
