import { Module } from '@nestjs/common';
import { PricingController } from './pricing.controller';
import { PricingService } from './pricing.service';
import { MarketPricingProvider } from './providers/market.provider';

@Module({
  controllers: [PricingController],
  providers: [PricingService, MarketPricingProvider],
  exports: [PricingService],
})
export class PricingModule {}
