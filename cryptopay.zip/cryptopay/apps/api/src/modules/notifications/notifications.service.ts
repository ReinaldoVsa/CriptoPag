import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

/**
 * Serviço de notificações (seção 34). Sem provedor de e-mail/push configurado,
 * os envios ficam registrados como PENDING e logados — nenhum e-mail/push real
 * é disparado até um provedor (ex: um serviço de e-mail transacional, FCM/APNs
 * para push) ser integrado.
 */
@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async notify(userId: string, event: string, title: string, body: string) {
    const notification = await this.prisma.notification.create({
      data: { userId, event, title, body, channel: 'EMAIL', status: 'PENDING' },
    });

    // TODO produção: integrar provedor real de e-mail/push aqui e atualizar
    // status para SENT/FAILED conforme o resultado do envio.
    this.logger.log(`[stub] Notificação "${event}" enfileirada para usuário ${userId}`);

    return notification;
  }

  async notifyKycApproved(userId: string) {
    return this.notify(userId, 'KYC_APPROVED', 'KYC aprovado', 'Sua verificação foi aprovada.');
  }

  async notifyKycRejected(userId: string) {
    return this.notify(userId, 'KYC_REJECTED', 'KYC rejeitado', 'Sua verificação foi rejeitada.');
  }

  async notifySellOrderCompleted(userId: string) {
    return this.notify(userId, 'SELL_ORDER_COMPLETED', 'Venda concluída', 'Sua venda foi concluída com sucesso.');
  }

  async notifyPixFailed(userId: string) {
    return this.notify(userId, 'PIX_FAILED', 'Pix falhou', 'Houve uma falha ao processar seu Pix.');
  }
}
