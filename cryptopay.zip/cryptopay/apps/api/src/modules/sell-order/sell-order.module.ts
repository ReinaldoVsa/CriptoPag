import { Module } from '@nestjs/common';
import { SellOrderController } from './sell-order.controller';
import { SellOrderService } from './sell-order.service';
import { OffRampPlaceholderProvider } from './providers/offramp-placeholder.provider';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [AuditModule],
  controllers: [SellOrderController],
  providers: [SellOrderService, OffRampPlaceholderProvider],
  exports: [SellOrderService],
})
export class SellOrderModule {}
