export interface CreateSellOrderInput {
  idempotencyKey: string;
  asset: string;
  cryptoAmount: string;
  txHash: string;
  expectedNetBRL: number;
}

export interface SellOrderResult {
  externalId: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
}

/**
 * Contrato para integração futura com parceiro de off-ramp (cripto -> BRL) real
 * (seção 18). Nenhuma exchange/parceiro foi contratado ainda — este contrato
 * existe para permitir o desenvolvimento do restante do fluxo sem inventar
 * uma integração.
 */
export interface OffRampProvider {
  createSellOrder(input: CreateSellOrderInput): Promise<SellOrderResult>;
  getOrderStatus(externalId: string): Promise<SellOrderResult>;
  cancelOrder(externalId: string): Promise<void>;
}
