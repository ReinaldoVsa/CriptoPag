import { VALID_TRANSITIONS } from './sell-order.service';

describe('SellOrder - máquina de estados', () => {
  it('permite o fluxo feliz completo do início ao fim', () => {
    const happyPath = [
      'CREATED',
      'QUOTED',
      'AWAITING_USER_AUTHORIZATION',
      'AUTHORIZED',
      'BROADCASTED',
      'CONFIRMING',
      'CONFIRMED',
      'CONVERTING',
      'BRL_AVAILABLE',
      'PIX_PENDING',
      'PIX_PROCESSING',
      'COMPLETED',
    ];

    for (let i = 0; i < happyPath.length - 1; i++) {
      const from = happyPath[i];
      const to = happyPath[i + 1];
      expect(VALID_TRANSITIONS[from]).toContain(to);
    }
  });

  it('nunca permite pular direto de CREATED para COMPLETED', () => {
    expect(VALID_TRANSITIONS['CREATED']).not.toContain('COMPLETED');
  });

  it('estados terminais não possuem transições de saída', () => {
    expect(VALID_TRANSITIONS['COMPLETED']).toEqual([]);
    expect(VALID_TRANSITIONS['FAILED']).toEqual([]);
    expect(VALID_TRANSITIONS['CANCELLED']).toEqual([]);
    expect(VALID_TRANSITIONS['EXPIRED']).toEqual([]);
  });

  it('não permite voltar de CONFIRMED para AWAITING_USER_AUTHORIZATION', () => {
    expect(VALID_TRANSITIONS['CONFIRMED']).not.toContain('AWAITING_USER_AUTHORIZATION');
  });
});
