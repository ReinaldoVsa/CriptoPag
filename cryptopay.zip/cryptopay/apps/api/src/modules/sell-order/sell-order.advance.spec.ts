import { Test } from '@nestjs/testing';
import { SellOrderService } from './sell-order.service';
import { PrismaService } from '../../prisma/prisma.service';
import { OffRampPlaceholderProvider } from './providers/offramp-placeholder.provider';
import { AuditService } from '../audit/audit.service';

describe('SellOrderService - advanceOnConfirmation', () => {
  let service: SellOrderService;
  let prisma: {
    sellOrder: { findFirst: jest.Mock; findUniqueOrThrow: jest.Mock; update: jest.Mock };
  };
  let offramp: { createSellOrder: jest.Mock };
  let audit: { log: jest.Mock };

  const baseOrder = {
    id: 'order-1',
    userId: 'user-1',
    txHash: '0xabc',
    quote: { asset: 'ETH', cryptoAmount: '1.5', netBRL: '9000' },
  };

  beforeEach(async () => {
    prisma = {
      sellOrder: {
        findFirst: jest.fn(),
        findUniqueOrThrow: jest.fn(),
        update: jest.fn(),
      },
    };
    offramp = { createSellOrder: jest.fn().mockResolvedValue({ externalId: 'offramp-123' }) };
    audit = { log: jest.fn() };

    const moduleRef = await Test.createTestingModule({
      providers: [
        SellOrderService,
        { provide: PrismaService, useValue: prisma },
        { provide: OffRampPlaceholderProvider, useValue: offramp },
        { provide: AuditService, useValue: audit },
      ],
    }).compile();

    service = moduleRef.get(SellOrderService);
  });

  it('mantém a ordem em BROADCASTED sem alterações se ainda não há nenhuma confirmação', async () => {
    prisma.sellOrder.findFirst.mockResolvedValue({ ...baseOrder, status: 'BROADCASTED' });

    await service.advanceOnConfirmation('order-1', 0, 12);

    expect(prisma.sellOrder.update).not.toHaveBeenCalled();
    expect(offramp.createSellOrder).not.toHaveBeenCalled();
  });

  it('move para CONFIRMING quando há confirmações parciais (abaixo do mínimo exigido)', async () => {
    prisma.sellOrder.findFirst.mockResolvedValue({ ...baseOrder, status: 'BROADCASTED' });
    prisma.sellOrder.findUniqueOrThrow.mockResolvedValue({ ...baseOrder, status: 'BROADCASTED' });
    prisma.sellOrder.update.mockResolvedValue({ ...baseOrder, status: 'CONFIRMING' });

    await service.advanceOnConfirmation('order-1', 5, 12);

    expect(prisma.sellOrder.update).toHaveBeenCalledWith({
      where: { id: 'order-1' },
      data: { status: 'CONFIRMING' },
    });
    expect(offramp.createSellOrder).not.toHaveBeenCalled();
  });

  it('completa CONFIRMED -> CONVERTING e cria a ordem no off-ramp quando atinge o mínimo de confirmações', async () => {
    prisma.sellOrder.findFirst.mockResolvedValue({ ...baseOrder, status: 'CONFIRMING' });
    prisma.sellOrder.findUniqueOrThrow
      .mockResolvedValueOnce({ ...baseOrder, status: 'CONFIRMING' })
      .mockResolvedValueOnce({ ...baseOrder, status: 'CONFIRMED' });
    prisma.sellOrder.update.mockResolvedValue({});

    const result = await service.advanceOnConfirmation('order-1', 12, 12);

    expect(offramp.createSellOrder).toHaveBeenCalledWith(
      expect.objectContaining({ idempotencyKey: 'offramp-order-1', txHash: '0xabc' }),
    );
    expect(result).toEqual({ externalId: 'offramp-123' });
    expect(audit.log).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'SELL_ORDER_BLOCKCHAIN_CONFIRMED' }),
    );
  });

  it('não faz nada se a ordem já avançou para um estado fora de BROADCASTED/CONFIRMING', async () => {
    prisma.sellOrder.findFirst.mockResolvedValue({ ...baseOrder, status: 'BRL_AVAILABLE' });

    await service.advanceOnConfirmation('order-1', 20, 12);

    expect(prisma.sellOrder.update).not.toHaveBeenCalled();
    expect(offramp.createSellOrder).not.toHaveBeenCalled();
  });
});
