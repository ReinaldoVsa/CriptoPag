import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { OffRampPlaceholderProvider } from './providers/offramp-placeholder.provider';
import { CreateSellOrderDto, AuthorizeSellOrderDto } from './dto/create-sell-order.dto';
import { AuditService } from '../audit/audit.service';

/**
 * Transições válidas da máquina de estados (seção 22). Qualquer transição fora
 * deste mapa é bloqueada — nunca pulamos etapas de confirmação.
 */
export const VALID_TRANSITIONS: Record<string, string[]> = {
  CREATED: ['QUOTED', 'CANCELLED', 'EXPIRED'],
  QUOTED: ['AWAITING_USER_AUTHORIZATION', 'CANCELLED', 'EXPIRED'],
  AWAITING_USER_AUTHORIZATION: ['AUTHORIZED', 'CANCELLED', 'EXPIRED'],
  AUTHORIZED: ['BROADCASTED', 'FAILED'],
  BROADCASTED: ['CONFIRMING', 'FAILED'],
  CONFIRMING: ['CONFIRMED', 'FAILED'],
  CONFIRMED: ['CONVERTING', 'FAILED'],
  CONVERTING: ['BRL_AVAILABLE', 'FAILED'],
  BRL_AVAILABLE: ['PIX_PENDING'],
  PIX_PENDING: ['PIX_PROCESSING', 'FAILED'],
  PIX_PROCESSING: ['COMPLETED', 'FAILED'],
  COMPLETED: [],
  FAILED: [],
  CANCELLED: [],
  EXPIRED: [],
};

@Injectable()
export class SellOrderService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly offramp: OffRampPlaceholderProvider, // trocar pelo parceiro real configurado
    private readonly audit: AuditService,
  ) {}

  private async transition(sellOrderId: string, to: string) {
    const order = await this.prisma.sellOrder.findUniqueOrThrow({ where: { id: sellOrderId } });
    const allowed = VALID_TRANSITIONS[order.status] ?? [];
    if (!allowed.includes(to)) {
      throw new BadRequestException(
        `Transição inválida: ${order.status} -> ${to}. Não é permitido pular etapas de confirmação.`,
      );
    }
    return this.prisma.sellOrder.update({ where: { id: sellOrderId }, data: { status: to as any } });
  }

  async create(userId: string, dto: CreateSellOrderDto) {
    const quote = await this.prisma.quote.findFirst({ where: { id: dto.quoteId, userId } });
    if (!quote) throw new NotFoundException('Cotação não encontrada.');
    if (quote.status !== 'CREATED' || quote.expiresAt < new Date()) {
      throw new BadRequestException('Cotação expirada ou inválida. Solicite uma nova.');
    }

    const wallet = await this.prisma.wallet.findFirst({ where: { id: dto.walletId, userId } });
    if (!wallet) throw new NotFoundException('Carteira não encontrada.');

    const idempotencyKey = `sell-${quote.id}`;
    const existing = await this.prisma.sellOrder.findUnique({ where: { idempotencyKey } });
    if (existing) return existing;

    const order = await this.prisma.sellOrder.create({
      data: {
        userId,
        walletId: wallet.id,
        quoteId: quote.id,
        idempotencyKey,
        status: 'QUOTED',
      },
    });

    await this.prisma.quote.update({ where: { id: quote.id }, data: { status: 'ACCEPTED' } });
    await this.transition(order.id, 'AWAITING_USER_AUTHORIZATION');

    await this.audit.log({
      userId,
      action: 'SELL_ORDER_CREATED',
      entityType: 'SellOrder',
      entityId: order.id,
    });

    return this.prisma.sellOrder.findUnique({ where: { id: order.id } });
  }

  /**
   * Usuário autoriza a transação (assinada via carteira conectada / WalletConnect
   * no frontend). O backend só marca AUTHORIZED após receber o txHash — a
   * confirmação real de que a blockchain aceitou vem depois, via polling/indexer
   * (BROADCASTED -> CONFIRMING -> CONFIRMED), nunca só pela ação do frontend.
   */
  async authorize(userId: string, sellOrderId: string, dto: AuthorizeSellOrderDto) {
    const order = await this.prisma.sellOrder.findFirst({ where: { id: sellOrderId, userId } });
    if (!order) throw new NotFoundException('Ordem de venda não encontrada.');

    await this.transition(sellOrderId, 'AUTHORIZED');
    await this.prisma.sellOrder.update({
      where: { id: sellOrderId },
      data: { txHash: dto.txHash },
    });

    await this.audit.log({
      userId,
      action: 'SELL_ORDER_AUTHORIZED',
      entityType: 'SellOrder',
      entityId: sellOrderId,
      metadata: { txHash: dto.txHash },
    });

    // A partir daqui, o IndexerService monitora o txHash e move
    // BROADCASTED -> CONFIRMING -> CONFIRMED conforme as confirmações
    // on-chain reais chegam (ver apps/api/src/modules/indexer).
    const final = await this.transition(sellOrderId, 'BROADCASTED');

    return final;
  }

  /**
   * Chamado pelo worker de indexação (IndexerService) a cada ciclo de polling
   * para uma ordem em BROADCASTED ou CONFIRMING. Avança a máquina de estados
   * de forma incremental conforme o número de confirmações on-chain:
   *  - ainda sem confirmações suficientes -> marca CONFIRMING (se ainda não estiver)
   *  - confirmações suficientes -> completa CONFIRMED -> CONVERTING e cria a
   *    ordem no parceiro de off-ramp
   * Nunca pula direto de BROADCASTED para CONVERTING sem passar pelos estados
   * intermediários — cada chamada de transition() valida o mapa de transições.
   */
  async advanceOnConfirmation(sellOrderId: string, confirmations: number, requiredConfirmations: number) {
    const order = await this.prisma.sellOrder.findFirst({
      where: { id: sellOrderId },
      include: { quote: true },
    });
    if (!order || !order.txHash) return;

    if (!['BROADCASTED', 'CONFIRMING'].includes(order.status)) {
      return; // já avançou (ou falhou) por outro caminho — nada a fazer
    }

    if (confirmations < requiredConfirmations) {
      if (order.status === 'BROADCASTED' && confirmations >= 1) {
        await this.transition(sellOrderId, 'CONFIRMING');
      }
      return;
    }

    // Confirmações suficientes atingidas: completa o restante do fluxo.
    if (order.status === 'BROADCASTED') {
      await this.transition(sellOrderId, 'CONFIRMING');
    }
    await this.transition(sellOrderId, 'CONFIRMED');
    await this.transition(sellOrderId, 'CONVERTING');

    await this.audit.log({
      userId: order.userId,
      action: 'SELL_ORDER_BLOCKCHAIN_CONFIRMED',
      entityType: 'SellOrder',
      entityId: order.id,
      metadata: { confirmations, txHash: order.txHash },
    });

    const result = await this.offramp.createSellOrder({
      idempotencyKey: `offramp-${order.id}`,
      asset: order.quote.asset,
      cryptoAmount: order.quote.cryptoAmount.toString(),
      txHash: order.txHash,
      expectedNetBRL: Number(order.quote.netBRL),
    });

    await this.prisma.sellOrder.update({
      where: { id: sellOrderId },
      data: { offrampExternalId: result.externalId },
    });

    return result;
  }

  /** Lista ordens que o indexer precisa monitorar (autorizadas, ainda não confirmadas). */
  async listPendingConfirmation() {
    return this.prisma.sellOrder.findMany({
      where: { status: { in: ['BROADCASTED', 'CONFIRMING'] }, txHash: { not: null } },
      include: { wallet: true },
    });
  }

  /** Marca uma ordem como falha (ex: erro inesperado do provedor de off-ramp durante o indexer). */
  async markFailed(sellOrderId: string, reason: string) {
    await this.prisma.sellOrder.update({
      where: { id: sellOrderId },
      data: { failureReason: reason },
    });
    return this.transition(sellOrderId, 'FAILED');
  }

  /** Chamado pelo webhook do off-ramp quando a conversão é confirmada. */
  async onOffRampCompleted(sellOrderId: string) {
    return this.transition(sellOrderId, 'BRL_AVAILABLE');
  }

  /** Chamado pelo webhook do Pix quando o pagamento é confirmado ou falha. */
  async onPixResult(sellOrderId: string, success: boolean) {
    await this.transition(sellOrderId, 'PIX_PROCESSING');
    return this.transition(sellOrderId, success ? 'COMPLETED' : 'FAILED');
  }

  async get(userId: string, id: string) {
    const order = await this.prisma.sellOrder.findFirst({
      where: { id, userId },
      include: { quote: true, pixPayment: true },
    });
    if (!order) throw new NotFoundException('Ordem de venda não encontrada.');
    return order;
  }

  async listHistory(userId: string) {
    return this.prisma.sellOrder.findMany({
      where: { userId },
      include: { quote: true, pixPayment: true },
      orderBy: { createdAt: 'desc' },
    });
  }
}
