import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import {
  CreateSellOrderInput,
  OffRampProvider,
  SellOrderResult,
} from '../offramp-provider.interface';

/**
 * Placeholder de parceiro de off-ramp (conversão cripto -> BRL). NÃO converte
 * ativos reais. Nenhum parceiro/exchange foi contratado — a regra fundamental
 * do produto proíbe inventar parceiros financeiros.
 *
 * Para produção: implemente esta interface com a API oficial do parceiro
 * escolhido, configure OFFRAMP_PROVIDER/OFFRAMP_API_URL/OFFRAMP_API_KEY/
 * OFFRAMP_API_SECRET/OFFRAMP_WEBHOOK_SECRET, e troque o provider no módulo.
 */
@Injectable()
export class OffRampPlaceholderProvider implements OffRampProvider {
  async createSellOrder(_input: CreateSellOrderInput): Promise<SellOrderResult> {
    throw new ServiceUnavailableException(
      'Nenhum parceiro de off-ramp configurado. Configure as variáveis OFFRAMP_* em .env antes de converter cripto para BRL.',
    );
  }

  async getOrderStatus(_externalId: string): Promise<SellOrderResult> {
    throw new ServiceUnavailableException('Nenhum parceiro de off-ramp configurado.');
  }

  async cancelOrder(_externalId: string): Promise<void> {
    throw new ServiceUnavailableException('Nenhum parceiro de off-ramp configurado.');
  }
}
