import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { SellOrderService } from './sell-order.service';
import { createSellOrderSchema, authorizeSellOrderSchema } from './dto/create-sell-order.dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('sell-orders')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller()
export class SellOrderController {
  constructor(private readonly sellOrderService: SellOrderService) {}

  @Get('transactions')
  async history(@CurrentUser('id') userId: string) {
    return this.sellOrderService.listHistory(userId);
  }

  @Post('sell-orders')
  async create(@CurrentUser('id') userId: string, @Body() body: unknown) {
    const dto = createSellOrderSchema.parse(body);
    return this.sellOrderService.create(userId, dto);
  }

  @Post('sell-orders/:id/authorize')
  async authorize(
    @CurrentUser('id') userId: string,
    @Param('id') id: string,
    @Body() body: unknown,
  ) {
    const dto = authorizeSellOrderSchema.parse(body);
    return this.sellOrderService.authorize(userId, id, dto);
  }

  @Get('sell-orders/:id')
  async get(@CurrentUser('id') userId: string, @Param('id') id: string) {
    return this.sellOrderService.get(userId, id);
  }
}
