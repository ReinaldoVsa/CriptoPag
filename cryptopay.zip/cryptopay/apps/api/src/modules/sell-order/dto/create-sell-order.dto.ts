import { z } from 'zod';

export const createSellOrderSchema = z.object({
  quoteId: z.string().uuid(),
  walletId: z.string().uuid(),
});
export type CreateSellOrderDto = z.infer<typeof createSellOrderSchema>;

export const authorizeSellOrderSchema = z.object({
  txHash: z.string().min(10),
});
export type AuthorizeSellOrderDto = z.infer<typeof authorizeSellOrderSchema>;
