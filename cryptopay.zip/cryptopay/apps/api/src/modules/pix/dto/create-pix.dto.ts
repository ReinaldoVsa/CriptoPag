import { z } from 'zod';

export const createPixPaymentSchema = z.object({
  sellOrderId: z.string().uuid(),
  pixKey: z.string().min(3).max(140),
  pixKeyType: z.enum(['CPF', 'CNPJ', 'EMAIL', 'PHONE', 'RANDOM']),
  beneficiaryName: z.string().max(120).optional(),
});
export type CreatePixPaymentDto = z.infer<typeof createPixPaymentSchema>;
