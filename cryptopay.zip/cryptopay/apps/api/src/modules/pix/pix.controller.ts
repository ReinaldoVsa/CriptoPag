import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PixService } from './pix.service';
import { createPixPaymentSchema } from './dto/create-pix.dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('pix')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('pix/payments')
export class PixController {
  constructor(private readonly pixService: PixService) {}

  @Post()
  async create(@CurrentUser('id') userId: string, @Body() body: unknown) {
    const dto = createPixPaymentSchema.parse(body);
    return this.pixService.createPayment(userId, dto);
  }

  @Get(':id')
  async get(@CurrentUser('id') userId: string, @Param('id') id: string) {
    return this.pixService.getPayment(userId, id);
  }
}
