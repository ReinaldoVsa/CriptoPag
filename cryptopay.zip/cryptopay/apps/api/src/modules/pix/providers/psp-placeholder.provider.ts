import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import {
  CreatePixPaymentInput,
  PixPaymentResult,
  PixProvider,
} from '../pix-provider.interface';

/**
 * Placeholder de PSP/instituição financeira. NÃO processa pagamentos reais.
 * Nenhuma instituição financeira foi contratada/configurada ainda — a regra
 * fundamental do produto proíbe inventar parceiros financeiros ou fingir
 * que um Pix foi concluído.
 *
 * Para produção: implemente esta interface com o SDK/API oficial do PSP
 * escolhido (ex: um banco parceiro com API de Pix), configure
 * PIX_PROVIDER/PIX_API_URL/PIX_API_KEY/PIX_API_SECRET/PIX_WEBHOOK_SECRET,
 * e troque o provider no PixModule.
 */
@Injectable()
export class PspPlaceholderProvider implements PixProvider {
  async createPixPayment(_input: CreatePixPaymentInput): Promise<PixPaymentResult> {
    throw new ServiceUnavailableException(
      'Nenhum PSP de Pix configurado. Configure as variáveis PIX_* em .env com um parceiro real antes de processar pagamentos.',
    );
  }

  async getPixPaymentStatus(_externalId: string): Promise<PixPaymentResult> {
    throw new ServiceUnavailableException('Nenhum PSP de Pix configurado.');
  }

  async handleWebhook(_rawPayload: unknown, _signature: string): Promise<PixPaymentResult> {
    throw new ServiceUnavailableException('Nenhum PSP de Pix configurado.');
  }
}
