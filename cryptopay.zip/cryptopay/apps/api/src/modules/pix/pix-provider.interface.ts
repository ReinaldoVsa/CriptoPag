export interface CreatePixPaymentInput {
  idempotencyKey: string;
  pixKey: string;
  pixKeyType: 'CPF' | 'CNPJ' | 'EMAIL' | 'PHONE' | 'RANDOM';
  amountBRL: number;
  beneficiaryName?: string;
}

export interface PixPaymentResult {
  externalId: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  endToEndId?: string;
}

/**
 * Contrato para integração futura com PSP/instituição financeira real (seção 19).
 * Pagamentos Pix só podem ser confirmados via backend + webhook oficial do PSP —
 * NUNCA confirmados apenas pelo frontend.
 */
export interface PixProvider {
  createPixPayment(input: CreatePixPaymentInput): Promise<PixPaymentResult>;
  getPixPaymentStatus(externalId: string): Promise<PixPaymentResult>;
  handleWebhook(rawPayload: unknown, signature: string): Promise<PixPaymentResult>;
}
