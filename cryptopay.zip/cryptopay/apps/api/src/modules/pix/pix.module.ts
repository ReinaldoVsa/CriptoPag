import { Module } from '@nestjs/common';
import { PixController } from './pix.controller';
import { PixService } from './pix.service';
import { PspPlaceholderProvider } from './providers/psp-placeholder.provider';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [AuditModule],
  controllers: [PixController],
  providers: [PixService, PspPlaceholderProvider],
  exports: [PixService],
})
export class PixModule {}
