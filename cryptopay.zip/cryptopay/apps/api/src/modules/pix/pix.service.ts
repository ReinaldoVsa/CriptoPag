import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { PspPlaceholderProvider } from './providers/psp-placeholder.provider';
import { CreatePixPaymentDto } from './dto/create-pix.dto';
import { AuditService } from '../audit/audit.service';
import * as crypto from 'crypto';

@Injectable()
export class PixService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly provider: PspPlaceholderProvider, // trocar pelo PSP real configurado
    private readonly audit: AuditService,
  ) {}

  async createPayment(userId: string, dto: CreatePixPaymentDto) {
    const sellOrder = await this.prisma.sellOrder.findFirst({
      where: { id: dto.sellOrderId, userId },
      include: { quote: true },
    });
    if (!sellOrder) throw new NotFoundException('Ordem de venda não encontrada.');
    if (sellOrder.status !== 'BRL_AVAILABLE') {
      throw new BadRequestException(
        'Pix só pode ser criado após a conversão para BRL ser confirmada.',
      );
    }

    // Idempotência: mesma sellOrder nunca gera dois pagamentos Pix distintos.
    const idempotencyKey = `pix-${sellOrder.id}`;
    const existing = await this.prisma.pixPayment.findUnique({ where: { idempotencyKey } });
    if (existing) return existing;

    const result = await this.provider.createPixPayment({
      idempotencyKey,
      pixKey: dto.pixKey,
      pixKeyType: dto.pixKeyType,
      amountBRL: Number(sellOrder.quote.netBRL),
      beneficiaryName: dto.beneficiaryName,
    });

    const payment = await this.prisma.pixPayment.create({
      data: {
        userId,
        idempotencyKey,
        pixKey: dto.pixKey,
        pixKeyType: dto.pixKeyType,
        amountBRL: sellOrder.quote.netBRL,
        beneficiaryName: dto.beneficiaryName,
        externalId: result.externalId,
        status: result.status,
      },
    });

    await this.prisma.sellOrder.update({
      where: { id: sellOrder.id },
      data: { pixPaymentId: payment.id, status: 'PIX_PENDING' },
    });

    await this.audit.log({
      userId,
      action: 'PIX_PAYMENT_CREATED',
      entityType: 'PixPayment',
      entityId: payment.id,
      metadata: { sellOrderId: sellOrder.id },
    });

    return payment;
  }

  async getPayment(userId: string, id: string) {
    const payment = await this.prisma.pixPayment.findFirst({ where: { id, userId } });
    if (!payment) throw new NotFoundException('Pagamento Pix não encontrado.');
    return payment;
  }

  /** Valida a assinatura HMAC do webhook do PSP contra PIX_WEBHOOK_SECRET. */
  verifyWebhookSignature(rawBody: string, signatureHeader: string | undefined): boolean {
    const secret = process.env.PIX_WEBHOOK_SECRET;
    if (!secret || !signatureHeader) return false;
    const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    try {
      return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signatureHeader));
    } catch {
      return false;
    }
  }
}
