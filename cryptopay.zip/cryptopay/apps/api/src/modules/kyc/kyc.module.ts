import { Module } from '@nestjs/common';
import { KycController } from './kyc.controller';
import { KycService } from './kyc.service';
import { SandboxKycProvider } from './providers/sandbox-kyc.provider';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [AuditModule],
  controllers: [KycController],
  providers: [KycService, SandboxKycProvider],
  exports: [KycService],
})
export class KycModule {}
