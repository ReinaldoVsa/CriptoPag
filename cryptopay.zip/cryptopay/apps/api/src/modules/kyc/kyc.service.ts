import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { SandboxKycProvider } from './providers/sandbox-kyc.provider';
import { AuditService } from '../audit/audit.service';

@Injectable()
export class KycService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly provider: SandboxKycProvider, // trocar pelo provedor real configurado
    private readonly audit: AuditService,
  ) {}

  async start(userId: string) {
    const verification = await this.provider.createVerification(userId);

    const record = await this.prisma.kycVerification.create({
      data: {
        userId,
        provider: process.env.KYC_PROVIDER || 'sandbox',
        externalId: verification.externalId,
        status: verification.status as any,
      },
    });

    await this.audit.log({
      userId,
      action: 'KYC_STARTED',
      entityType: 'KycVerification',
      entityId: record.id,
    });

    return { verificationId: record.id, status: record.status, redirectUrl: verification.redirectUrl };
  }

  async getStatus(userId: string) {
    const latest = await this.prisma.kycVerification.findFirst({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });
    if (!latest) return { status: 'NOT_STARTED' };
    return { status: latest.status, reason: latest.reason };
  }
}
