import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import { KycProvider, KycStatusResult, KycVerification } from '../kyc-provider.interface';

/**
 * Adapter placeholder de SANDBOX. NÃO é uma integração real com nenhum provedor.
 * Existe apenas para permitir que o restante do sistema (fluxos, testes, UI)
 * seja desenvolvido antes da contratação de um provedor real de KYC/AML.
 *
 * Este provider FICA INATIVO por padrão (ver Integration.isActive no admin) e
 * lança erro se alguém tentar usá-lo fora de NODE_ENV=development, para
 * impedir que "KYC fictício" chegue a produção — regra explícita da seção 9.
 */
@Injectable()
export class SandboxKycProvider implements KycProvider {
  async createVerification(userId: string): Promise<KycVerification> {
    this.assertSandboxOnly();
    return {
      externalId: `sandbox-kyc-${userId}-${Date.now()}`,
      status: 'PENDING',
      redirectUrl: undefined,
    };
  }

  async getVerificationStatus(externalId: string): Promise<KycStatusResult> {
    this.assertSandboxOnly();
    // Em sandbox, todo pedido permanece IN_REVIEW até revisão manual no /admin —
    // nunca aprovamos automaticamente, mesmo em ambiente de teste.
    return { status: 'IN_REVIEW' };
  }

  private assertSandboxOnly() {
    if (process.env.NODE_ENV === 'production') {
      throw new ServiceUnavailableException(
        'Provedor de KYC real não configurado. Configure KYC_PROVIDER em .env antes de operar em produção.',
      );
    }
  }
}
