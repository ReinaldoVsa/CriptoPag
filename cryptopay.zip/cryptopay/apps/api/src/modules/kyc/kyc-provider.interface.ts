export interface KycVerification {
  externalId: string;
  status: 'PENDING' | 'IN_REVIEW' | 'APPROVED' | 'REJECTED' | 'REQUIRES_REVIEW';
  redirectUrl?: string;
}

export interface KycStatusResult {
  status: 'PENDING' | 'IN_REVIEW' | 'APPROVED' | 'REJECTED' | 'REQUIRES_REVIEW';
  reason?: string;
}

/**
 * Contrato para integração futura com provedor real de KYC/AML (seção 9).
 * Nenhum provedor real está implementado aqui — nunca simulamos aprovação de KYC.
 * Ao integrar um provedor real, implemente esta interface e configure
 * KYC_PROVIDER / KYC_API_KEY / KYC_API_SECRET / KYC_WEBHOOK_SECRET em .env.
 */
export interface KycProvider {
  createVerification(userId: string): Promise<KycVerification>;
  getVerificationStatus(externalId: string): Promise<KycStatusResult>;
}
