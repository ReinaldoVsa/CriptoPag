import { z } from 'zod';

/**
 * Validação de cadastro com Zod (regra: backend nunca confia em validação apenas do frontend).
 * CPF é validado em formato; validação de dígito verificador real deve ser adicionada
 * antes de produção (não implementada aqui para não simular verificação real da Receita).
 */
export const registerSchema = z.object({
  fullName: z.string().min(3).max(120),
  cpf: z.string().regex(/^\d{11}$/, 'CPF deve conter 11 dígitos numéricos'),
  birthDate: z.coerce.date(),
  email: z.string().email(),
  phone: z.string().min(10).max(20).optional(),
  password: z.string().min(8).max(72),
  passwordConfirmation: z.string(),
  acceptedTerms: z.literal(true),
  acceptedPrivacy: z.literal(true),
}).refine((data) => data.password === data.passwordConfirmation, {
  message: 'As senhas não coincidem',
  path: ['passwordConfirmation'],
});

export type RegisterDto = z.infer<typeof registerSchema>;
