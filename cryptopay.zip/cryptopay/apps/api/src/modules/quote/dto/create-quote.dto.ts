import { z } from 'zod';

export const createQuoteSchema = z.object({
  walletId: z.string().uuid(),
  asset: z.string().min(2).max(10),
  cryptoAmount: z.coerce.number().positive(),
});
export type CreateQuoteDto = z.infer<typeof createQuoteSchema>;
