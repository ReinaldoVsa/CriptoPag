import { Module } from '@nestjs/common';
import { QuoteController } from './quote.controller';
import { QuoteService } from './quote.service';
import { PricingModule } from '../pricing/pricing.module';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [PricingModule, AuditModule],
  controllers: [QuoteController],
  providers: [QuoteService],
  exports: [QuoteService],
})
export class QuoteModule {}
