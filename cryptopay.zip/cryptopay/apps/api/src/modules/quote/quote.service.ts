import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { PricingService } from '../pricing/pricing.service';
import { CreateQuoteDto } from './dto/create-quote.dto';
import { AuditService } from '../audit/audit.service';

const QUOTE_TTL_SECONDS = 30;
const SERVICE_FEE_PERCENT = 0.005; // 0.5% — taxa de serviço configurável
const SPREAD_PERCENT = 0.003; // 0.3% — spread configurável
const ESTIMATED_NETWORK_FEE_BRL: Record<string, number> = {
  BTC: 8,
  ETH: 15,
};

@Injectable()
export class QuoteService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly pricing: PricingService,
    private readonly audit: AuditService,
  ) {}

  async createQuote(userId: string, dto: CreateQuoteDto) {
    const wallet = await this.prisma.wallet.findFirst({
      where: { id: dto.walletId, userId },
    });
    if (!wallet) throw new NotFoundException('Carteira não encontrada.');

    const asset = await this.prisma.walletAsset.findFirst({
      where: { walletId: wallet.id, assetSymbol: dto.asset },
    });
    if (!asset || Number(asset.balance) < dto.cryptoAmount) {
      throw new BadRequestException('Saldo insuficiente para a quantidade solicitada.');
    }

    // Backend SEMPRE busca a cotação atual — nunca confia em valor enviado pelo cliente.
    const price = await this.pricing.getPrice(dto.asset, 'BRL');
    const grossBRL = dto.cryptoAmount * price.value;
    const networkFee = ESTIMATED_NETWORK_FEE_BRL[dto.asset.toUpperCase()] ?? 5;
    const serviceFee = grossBRL * SERVICE_FEE_PERCENT;
    const spread = grossBRL * SPREAD_PERCENT;
    const netBRL = grossBRL - networkFee - serviceFee - spread;

    if (netBRL <= 0) {
      throw new BadRequestException('Valor líquido resultante é inválido após taxas.');
    }

    const quote = await this.prisma.quote.create({
      data: {
        userId,
        asset: dto.asset.toUpperCase(),
        cryptoAmount: dto.cryptoAmount,
        cryptoPrice: price.value,
        grossBRL,
        networkFee,
        serviceFee,
        spread,
        netBRL,
        expiresAt: new Date(Date.now() + QUOTE_TTL_SECONDS * 1000),
      },
    });

    await this.audit.log({
      userId,
      action: 'QUOTE_CREATED',
      entityType: 'Quote',
      entityId: quote.id,
      metadata: { asset: dto.asset, cryptoAmount: dto.cryptoAmount },
    });

    return quote;
  }

  async getQuote(userId: string, quoteId: string) {
    const quote = await this.prisma.quote.findFirst({ where: { id: quoteId, userId } });
    if (!quote) throw new NotFoundException('Cotação não encontrada.');

    if (quote.status === 'CREATED' && quote.expiresAt < new Date()) {
      await this.prisma.quote.update({ where: { id: quote.id }, data: { status: 'EXPIRED' } });
      quote.status = 'EXPIRED';
    }
    return quote;
  }
}
