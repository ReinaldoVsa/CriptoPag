import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class AdminService {
  constructor(private readonly prisma: PrismaService) {}

  async dashboard() {
    const [totalUsers, kycApproved, sellOrders, pixPayments, failedWebhooks] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.kycVerification.count({ where: { status: 'APPROVED' } }),
      this.prisma.sellOrder.count(),
      this.prisma.pixPayment.count(),
      this.prisma.webhookEvent.count({ where: { processingStatus: 'FAILED' } }),
    ]);

    return { totalUsers, kycApproved, sellOrders, pixPayments, failedWebhooks };
  }

  async listUsers(page = 1, pageSize = 20, search?: string) {
    const where = search
      ? {
          OR: [
            { email: { contains: search, mode: 'insensitive' as const } },
            { fullName: { contains: search, mode: 'insensitive' as const } },
          ],
        }
      : {};

    const [items, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.user.count({ where }),
    ]);

    return { items, total, page, pageSize };
  }

  async listIntegrations() {
    // Secrets nunca são retornados — apenas se existem (hasSecret) e status mascarado.
    return this.prisma.integration.findMany({ orderBy: { category: 'asc' } });
  }

  async listAuditLogs(page = 1, pageSize = 50) {
    const [items, total] = await Promise.all([
      this.prisma.auditLog.findMany({
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.auditLog.count(),
    ]);
    return { items, total, page, pageSize };
  }

  async listWebhookEvents(page = 1, pageSize = 50) {
    const [items, total] = await Promise.all([
      this.prisma.webhookEvent.findMany({
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { receivedAt: 'desc' },
      }),
      this.prisma.webhookEvent.count(),
    ]);
    return { items, total, page, pageSize };
  }
}
