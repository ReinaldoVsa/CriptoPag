import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('admin')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('dashboard')
  dashboard() {
    return this.adminService.dashboard();
  }

  @Get('users')
  users(@Query('page') page?: string, @Query('search') search?: string) {
    return this.adminService.listUsers(Number(page) || 1, 20, search);
  }

  @Get('integrations')
  integrations() {
    return this.adminService.listIntegrations();
  }

  @Get('audit-logs')
  auditLogs(@Query('page') page?: string) {
    return this.adminService.listAuditLogs(Number(page) || 1);
  }

  @Get('webhooks')
  webhooks(@Query('page') page?: string) {
    return this.adminService.listWebhookEvents(Number(page) || 1);
  }
}
