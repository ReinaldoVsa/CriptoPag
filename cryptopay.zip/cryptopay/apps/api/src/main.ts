import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log'],
    rawBody: true,
  });

  // Segurança básica de headers HTTP
  app.use(helmet());

  // CORS restrito ao frontend configurado
  app.enableCors({
    origin: process.env.FRONTEND_URL?.split(',') ?? true,
    credentials: true,
  });

  // Validação global de DTOs (Zod é usado dentro dos services/pipes específicos,
  // ValidationPipe cobre validação básica de classe quando aplicável)
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  app.useGlobalFilters(new HttpExceptionFilter());

  app.setGlobalPrefix('api/v1', {
    exclude: ['health', 'ready'],
  });

  // Documentação OpenAPI/Swagger
  const config = new DocumentBuilder()
    .setTitle('CryptoPay API')
    .setDescription('API da plataforma CryptoPay — carteira cripto, cotação, venda e Pix')
    .setVersion('0.1.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('docs', app, document);

  const port = process.env.PORT ?? 3001;
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`CryptoPay API rodando na porta ${port} — docs em /docs`);
}

bootstrap();
