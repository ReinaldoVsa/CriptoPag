'use client';

import { useEffect } from 'react';

export function ServiceWorkerRegister() {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {
        // Falha silenciosa: PWA funciona parcialmente sem SW (sem offline/instalável).
      });
    }
  }, []);

  return null;
}
