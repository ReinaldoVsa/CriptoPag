import Link from 'next/link';

export default function LandingPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center gap-8 px-6 text-center">
      <div className="space-y-3">
        <h1 className="text-4xl font-bold tracking-tight">CryptoPay</h1>
        <p className="text-neutral-400 max-w-md">
          Consulte o saldo da sua carteira cripto, veja o valor estimado em reais
          e, quando disponível, venda com recebimento via Pix.
        </p>
      </div>
      <div className="flex gap-4">
        <Link
          href="/cadastro"
          className="px-6 py-3 rounded-lg bg-brand hover:bg-brand-light transition font-medium"
        >
          Criar conta
        </Link>
        <Link
          href="/login"
          className="px-6 py-3 rounded-lg border border-neutral-700 hover:border-neutral-500 transition font-medium"
        >
          Entrar
        </Link>
      </div>
      <p className="text-xs text-neutral-600 max-w-sm">
        Não custodial: nunca solicitamos sua seed phrase ou chave privada.
      </p>
    </main>
  );
}
