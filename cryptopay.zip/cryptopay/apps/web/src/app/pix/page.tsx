'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { apiFetch } from '@/lib/api';

const KEY_TYPES = ['CPF', 'CNPJ', 'EMAIL', 'PHONE', 'RANDOM'] as const;

interface PixPayment {
  id: string;
  status: string;
  amountBRL: string;
}

export default function PixPage() {
  const params = useSearchParams();
  const sellOrderId = params.get('sellOrderId') ?? '';

  const [pixKey, setPixKey] = useState('');
  const [pixKeyType, setPixKeyType] = useState<(typeof KEY_TYPES)[number]>('CPF');
  const [payment, setPayment] = useState<PixPayment | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const result = await apiFetch<PixPayment>('/pix/payments', {
        method: 'POST',
        body: JSON.stringify({ sellOrderId, pixKey, pixKeyType }),
      });
      setPayment(result);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen px-6 py-10 max-w-md mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Receber via Pix</h1>

      {!payment && (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm mb-1 text-neutral-400">Tipo de chave</label>
            <select
              value={pixKeyType}
              onChange={(e) => setPixKeyType(e.target.value as any)}
              className="w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2"
            >
              {KEY_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm mb-1 text-neutral-400">Chave Pix</label>
            <input
              required
              value={pixKey}
              onChange={(e) => setPixKey(e.target.value)}
              className="w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2"
            />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-brand hover:bg-brand-light font-medium disabled:opacity-50"
          >
            {loading ? 'Enviando...' : 'Confirmar recebimento via Pix'}
          </button>
        </form>
      )}

      {payment && (
        <div className="rounded-xl border border-neutral-800 p-4 space-y-2">
          <p className="text-sm text-neutral-500">Status</p>
          <p className="text-lg font-semibold">{payment.status}</p>
          <p className="text-sm text-neutral-500">Valor: R$ {payment.amountBRL}</p>
          <p className="text-xs text-neutral-600">
            O status é atualizado automaticamente assim que o backend recebe a
            confirmação oficial do PSP via webhook — nunca é marcado como concluído
            apenas pelo frontend.
          </p>
        </div>
      )}
    </main>
  );
}
