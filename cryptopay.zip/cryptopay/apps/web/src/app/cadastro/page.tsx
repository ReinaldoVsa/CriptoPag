'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { apiFetch, setAccessToken } from '@/lib/api';

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    fullName: '',
    cpf: '',
    birthDate: '',
    email: '',
    phone: '',
    password: '',
    passwordConfirmation: '',
  });
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function update(field: keyof typeof form, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!acceptedTerms || !acceptedPrivacy) {
      setError('É necessário aceitar os termos e a política de privacidade.');
      return;
    }

    setLoading(true);
    try {
      const { accessToken } = await apiFetch<{ accessToken: string }>('/auth/register', {
        method: 'POST',
        auth: false,
        body: JSON.stringify({ ...form, acceptedTerms, acceptedPrivacy }),
      });
      setAccessToken(accessToken);
      router.push('/dashboard');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-12">
      <form onSubmit={handleSubmit} className="w-full max-w-md space-y-4">
        <h1 className="text-2xl font-semibold">Criar conta</h1>

        <Field label="Nome completo" value={form.fullName} onChange={(v) => update('fullName', v)} />
        <Field label="CPF (somente números)" value={form.cpf} onChange={(v) => update('cpf', v)} />
        <Field label="Data de nascimento" type="date" value={form.birthDate} onChange={(v) => update('birthDate', v)} />
        <Field label="E-mail" type="email" value={form.email} onChange={(v) => update('email', v)} />
        <Field label="Telefone" value={form.phone} onChange={(v) => update('phone', v)} />
        <Field label="Senha" type="password" value={form.password} onChange={(v) => update('password', v)} />
        <Field
          label="Confirmar senha"
          type="password"
          value={form.passwordConfirmation}
          onChange={(v) => update('passwordConfirmation', v)}
        />

        <label className="flex items-start gap-2 text-sm text-neutral-400">
          <input type="checkbox" checked={acceptedTerms} onChange={(e) => setAcceptedTerms(e.target.checked)} />
          Li e aceito os termos de uso.
        </label>
        <label className="flex items-start gap-2 text-sm text-neutral-400">
          <input type="checkbox" checked={acceptedPrivacy} onChange={(e) => setAcceptedPrivacy(e.target.checked)} />
          Li e aceito a política de privacidade.
        </label>

        {error && <p className="text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 rounded-lg bg-brand hover:bg-brand-light transition font-medium disabled:opacity-50"
        >
          {loading ? 'Criando conta...' : 'Criar conta'}
        </button>
      </form>
    </main>
  );
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <div>
      <label className="block text-sm mb-1 text-neutral-400">{label}</label>
      <input
        type={type}
        required
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2 focus:outline-none focus:border-brand"
      />
    </div>
  );
}
