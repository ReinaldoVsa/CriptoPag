'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { apiFetch } from '@/lib/api';

const NETWORKS = ['BITCOIN', 'ETHEREUM', 'POLYGON', 'BSC', 'ARBITRUM'];

export default function AddWalletPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'manual' | 'qrcode' | 'walletconnect'>('manual');
  const [address, setAddress] = useState('');
  const [network, setNetwork] = useState('BITCOIN');
  const [label, setLabel] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await apiFetch('/wallets', {
        method: 'POST',
        body: JSON.stringify({ address, network, label, source: mode.toUpperCase() }),
      });
      router.push('/dashboard');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen px-6 py-10 max-w-md mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Adicionar carteira</h1>

      <div className="flex gap-2 text-sm">
        {(['manual', 'qrcode', 'walletconnect'] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`px-3 py-1.5 rounded-lg border ${
              mode === m ? 'border-brand text-brand' : 'border-neutral-800 text-neutral-500'
            }`}
          >
            {m === 'manual' ? 'Colar endereço' : m === 'qrcode' ? 'Ler QR Code' : 'WalletConnect'}
          </button>
        ))}
      </div>

      {mode === 'walletconnect' && (
        <div className="rounded-xl border border-neutral-800 p-6 text-center text-neutral-500 text-sm">
          Conexão via WalletConnect requer NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID configurado
          e o componente de modal do WalletConnect (@walletconnect/modal). Integração completa
          fica no client-side, disparando a leitura do endereço público após a conexão e
          preenchendo os campos abaixo automaticamente.
        </div>
      )}

      {mode === 'qrcode' && (
        <div className="rounded-xl border border-neutral-800 p-6 text-center text-neutral-500 text-sm">
          Leitor de QR Code (biblioteca html5-qrcode) deve ser montado aqui em um componente
          client-only, chamando setAddress(...) com o valor decodificado ao detectar um QR válido.
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm mb-1 text-neutral-400">Rede</label>
          <select
            value={network}
            onChange={(e) => setNetwork(e.target.value)}
            className="w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2"
          >
            {NETWORKS.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm mb-1 text-neutral-400">Endereço público</label>
          <input
            required
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="0x... ou bc1..."
            className="w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2 font-mono text-sm"
          />
        </div>

        <div>
          <label className="block text-sm mb-1 text-neutral-400">Apelido (opcional)</label>
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            className="w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2"
          />
        </div>

        {error && <p className="text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 rounded-lg bg-brand hover:bg-brand-light transition font-medium disabled:opacity-50"
        >
          {loading ? 'Validando...' : 'Adicionar carteira'}
        </button>
      </form>
    </main>
  );
}
