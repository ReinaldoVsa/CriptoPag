'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';

interface Profile {
  fullName: string;
  email: string;
  role: string;
}

interface KycStatus {
  status: string;
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [kyc, setKyc] = useState<KycStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<Profile>('/users/me').then(setProfile).catch((e) => setError(e.message));
    apiFetch<KycStatus>('/kyc/status').then(setKyc).catch(() => {});
  }, []);

  async function startKyc() {
    try {
      await apiFetch('/kyc/start', { method: 'POST' });
      const status = await apiFetch<KycStatus>('/kyc/status');
      setKyc(status);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <main className="min-h-screen px-6 py-10 max-w-md mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Perfil</h1>

      {error && <p className="text-sm text-red-400">{error}</p>}

      {profile && (
        <div className="rounded-xl border border-neutral-800 p-4 space-y-1">
          <p className="font-medium">{profile.fullName}</p>
          <p className="text-sm text-neutral-500">{profile.email}</p>
        </div>
      )}

      <div className="rounded-xl border border-neutral-800 p-4 space-y-3">
        <p className="text-sm text-neutral-500">Verificação de identidade (KYC)</p>
        <p className="font-medium">{kyc?.status ?? 'NOT_STARTED'}</p>
        {(!kyc || kyc.status === 'NOT_STARTED') && (
          <button
            onClick={startKyc}
            className="px-4 py-2 rounded-lg bg-brand hover:bg-brand-light text-sm font-medium"
          >
            Iniciar verificação
          </button>
        )}
      </div>
    </main>
  );
}
