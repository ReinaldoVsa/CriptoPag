'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiFetch } from '@/lib/api';

interface Wallet {
  id: string;
  label?: string;
  address: string;
  network: string;
}

export default function DashboardPage() {
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<Wallet[]>('/wallets')
      .then(setWallets)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <main className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-8">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Minhas carteiras</h1>
        <div className="flex gap-3">
          <Link href="/carteiras/adicionar" className="px-4 py-2 rounded-lg bg-brand hover:bg-brand-light text-sm font-medium">
            Adicionar carteira
          </Link>
          <Link href="/historico" className="px-4 py-2 rounded-lg border border-neutral-700 text-sm font-medium">
            Histórico
          </Link>
        </div>
      </header>

      {loading && <p className="text-neutral-500">Carregando...</p>}
      {error && <p className="text-red-400">{error}</p>}

      {!loading && wallets.length === 0 && (
        <div className="rounded-xl border border-dashed border-neutral-800 p-10 text-center text-neutral-500">
          Nenhuma carteira adicionada ainda.
        </div>
      )}

      <div className="grid gap-4">
        {wallets.map((w) => (
          <Link
            key={w.id}
            href={`/venda?walletId=${w.id}`}
            className="block rounded-xl border border-neutral-800 p-4 hover:border-brand transition"
          >
            <p className="font-medium">{w.label ?? w.network}</p>
            <p className="text-sm text-neutral-500 truncate">{w.address}</p>
            <p className="text-xs text-neutral-600 mt-1">{w.network}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
