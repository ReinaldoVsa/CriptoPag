'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';

interface HistoryItem {
  id: string;
  status: string;
  createdAt: string;
  quote: { asset: string; cryptoAmount: string; netBRL: string };
}

export default function HistoryPage() {
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<HistoryItem[]>('/transactions')
      .then(setItems)
      .catch((e) => setError(e.message));
  }, []);

  return (
    <main className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Histórico</h1>

      {error && <p className="text-sm text-red-400">{error}</p>}

      {items.length === 0 && !error && (
        <p className="text-neutral-500">Nenhuma operação registrada ainda.</p>
      )}

      <div className="space-y-3">
        {items.map((item) => (
          <div key={item.id} className="rounded-xl border border-neutral-800 p-4 flex justify-between items-center">
            <div>
              <p className="font-medium">
                {item.quote.cryptoAmount} {item.quote.asset}
              </p>
              <p className="text-sm text-neutral-500">
                {new Date(item.createdAt).toLocaleString('pt-BR')}
              </p>
            </div>
            <div className="text-right">
              <p className="font-medium">R$ {item.quote.netBRL}</p>
              <p className="text-xs text-neutral-500">{item.status}</p>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
