'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { apiFetch } from '@/lib/api';

interface BalanceResponse {
  native: { asset: string; amount: string };
  estimatedBRL: string;
  priceBRL: number;
  disclaimer: string;
}

interface Quote {
  id: string;
  netBRL: string;
  cryptoAmount: string;
  asset: string;
  expiresAt: string;
}

export default function SellPage() {
  const params = useSearchParams();
  const walletId = params.get('walletId') ?? '';

  const [balance, setBalance] = useState<BalanceResponse | null>(null);
  const [amount, setAmount] = useState('');
  const [quote, setQuote] = useState<Quote | null>(null);
  const [sellOrderId, setSellOrderId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!walletId) return;
    apiFetch<BalanceResponse>(`/wallets/${walletId}/balance`).then(setBalance).catch((e) => setError(e.message));
  }, [walletId]);

  async function requestQuote() {
    setError(null);
    setLoading(true);
    try {
      const q = await apiFetch<Quote>('/quotes', {
        method: 'POST',
        body: JSON.stringify({ walletId, asset: balance?.native.asset, cryptoAmount: amount }),
      });
      setQuote(q);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function confirmSell() {
    if (!quote) return;
    setError(null);
    setLoading(true);
    try {
      const order = await apiFetch<{ id: string }>('/sell-orders', {
        method: 'POST',
        body: JSON.stringify({ quoteId: quote.id, walletId }),
      });
      setSellOrderId(order.id);
      // A partir daqui, o próximo passo é o usuário assinar a transação na
      // carteira conectada (WalletConnect) e enviar o txHash para
      // POST /sell-orders/:id/authorize — não implementado neste stub de UI.
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen px-6 py-10 max-w-md mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Vender cripto</h1>

      {balance && (
        <div className="rounded-xl border border-neutral-800 p-4 space-y-1">
          <p className="text-sm text-neutral-500">Saldo disponível</p>
          <p className="text-xl font-semibold">
            {balance.native.amount} {balance.native.asset}
          </p>
          <p className="text-sm text-neutral-500">
            ≈ R$ {balance.estimatedBRL} • {balance.disclaimer}
          </p>
        </div>
      )}

      {!quote && (
        <div className="space-y-3">
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={`Quantidade em ${balance?.native.asset ?? ''}`}
            className="w-full rounded-lg bg-neutral-900 border border-neutral-800 px-3 py-2"
          />
          <button
            onClick={requestQuote}
            disabled={loading || !amount}
            className="w-full py-2.5 rounded-lg bg-brand hover:bg-brand-light font-medium disabled:opacity-50"
          >
            {loading ? 'Calculando...' : 'Calcular cotação'}
          </button>
        </div>
      )}

      {quote && !sellOrderId && (
        <div className="rounded-xl border border-neutral-800 p-4 space-y-2">
          <p className="text-sm text-neutral-500">Você receberá (líquido)</p>
          <p className="text-2xl font-semibold">R$ {quote.netBRL}</p>
          <p className="text-xs text-neutral-600">
            Cotação válida até {new Date(quote.expiresAt).toLocaleTimeString('pt-BR')}
          </p>
          <button
            onClick={confirmSell}
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-brand hover:bg-brand-light font-medium disabled:opacity-50"
          >
            Confirmar venda
          </button>
        </div>
      )}

      {sellOrderId && (
        <div className="rounded-xl border border-green-900 bg-green-950/30 p-4 text-sm">
          Ordem de venda criada ({sellOrderId}). Autorize a transação na sua carteira
          conectada para prosseguir — a confirmação final depende da blockchain.
        </div>
      )}

      {error && <p className="text-sm text-red-400">{error}</p>}
    </main>
  );
}
