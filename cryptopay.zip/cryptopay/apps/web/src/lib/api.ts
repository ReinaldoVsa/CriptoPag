const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:3001';

let accessToken: string | null = null;

/** Guarda o access token apenas em memória (nunca em localStorage) — o refresh
 * token fica em cookie HttpOnly gerenciado pelo backend. */
export function setAccessToken(token: string | null) {
  accessToken = token;
}

export function getAccessToken() {
  return accessToken;
}

interface RequestOptions extends RequestInit {
  auth?: boolean;
}

export async function apiFetch<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { auth = true, headers, ...rest } = options;

  const res = await fetch(`${API_URL}/api/v1${path}`, {
    ...rest,
    credentials: 'include', // envia cookie de refresh token quando necessário
    headers: {
      'Content-Type': 'application/json',
      ...(auth && accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      ...headers,
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message?.message ?? body?.message ?? `Erro ${res.status}`);
  }

  return res.json();
}
