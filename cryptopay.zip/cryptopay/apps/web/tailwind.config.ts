import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#5B21B6',
          dark: '#4C1D95',
          light: '#7C3AED',
        },
      },
    },
  },
  plugins: [],
};
export default config;
