# apps/

Aplicações executáveis do monorepo:

- **web/** — Frontend Next.js (Web + PWA). Único codebase reaproveitado
  também pelo app Android via Capacitor.
- **api/** — Backend NestJS: autenticação, regras de negócio, integrações
  com blockchain/cotação/off-ramp/Pix/KYC, banco de dados (Prisma), painel
  administrativo.
- **mobile/** — Wrapper Capacitor que empacota `apps/web` como app Android
  nativo. Ver `apps/mobile/README.md` para o passo a passo de build do
  APK/AAB.
