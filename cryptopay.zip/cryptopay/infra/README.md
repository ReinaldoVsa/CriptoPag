# infra/

Reservado para artefatos de infraestrutura como código (ex: Terraform,
Pulumi) do backend em cloud, quando o provedor de hospedagem for escolhido
(ver `docs/deployment.md`). Vazio nesta versão — o deploy atual é feito via
Docker + configuração manual no painel do provedor escolhido.
