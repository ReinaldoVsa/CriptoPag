# tests/

Reservado para testes de integração que atravessam múltiplos módulos da API
(ex: fluxo completo de venda usando um banco de teste real). Os testes
unitários atuais vivem junto ao código-fonte em `apps/api/src/**/*.spec.ts`
(convenção padrão do Jest/NestJS). Vazio nesta versão.
