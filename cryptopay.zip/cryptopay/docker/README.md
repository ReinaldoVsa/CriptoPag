# docker/

Os arquivos `Dockerfile` (backend) e `apps/web/Dockerfile` (frontend) ficam
na raiz e em `apps/web/` respectivamente, junto ao `docker-compose.yml` na
raiz — local convencional para essas ferramentas encontrarem o contexto de
build do monorepo. Esta pasta fica reservada para Dockerfiles adicionais
(ex: um worker de indexação de blockchain futuro) ou scripts de
entrypoint/healthcheck customizados.
