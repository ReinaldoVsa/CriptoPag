# Pix — CryptoPay

Interface: `apps/api/src/modules/pix/pix-provider.interface.ts`.

**Nenhum PSP/instituição financeira está integrado.** O adapter atual
(`PspPlaceholderProvider`) lança erro explícito em qualquer chamada.

Um pagamento Pix só é confirmado como `COMPLETED` através de:
1. O backend cria o pagamento junto ao PSP (`PixProvider.createPixPayment`).
2. O PSP envia um webhook assinado para `POST /api/v1/webhooks/pix`.
3. `WebhooksService` valida a assinatura HMAC (`PIX_WEBHOOK_SECRET`) e só
   então atualiza o status da `SellOrder` associada.

O frontend nunca marca um Pix como concluído — apenas exibe o status vindo
do backend.

## Para integrar um PSP real
1. Contratar/configurar um PSP ou instituição financeira parceira com API
   de Pix (envio e recebimento de webhooks).
2. Implementar `PixProvider` com a API oficial do PSP.
3. Configurar `PIX_PROVIDER`, `PIX_API_URL`, `PIX_API_KEY`, `PIX_API_SECRET`,
   `PIX_WEBHOOK_SECRET` em `.env`.
4. Trocar o provider injetado em `PixModule`.
