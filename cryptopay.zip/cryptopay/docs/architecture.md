# Arquitetura — CryptoPay

## Visão geral

```
USUÁRIO
  │
  ▼
CRYPTOPAY PWA / ANDROID (Next.js + Capacitor)
  │
  ▼
API NESTJS (apps/api)
  │
  ├── Auth Module (JWT + refresh cookie, RBAC)
  ├── Wallet Module ──► BlockchainProvider (BlockCypher / Alchemy / RPC)
  ├── Pricing Module ──► PricingProvider (CoinGecko por padrão)
  ├── Quote Module (cotação temporária, recalculada sempre no backend)
  ├── SellOrder Module (máquina de estados CREATED → COMPLETED)
  │     └──► OffRampProvider (placeholder até parceiro real)
  ├── Pix Module ──► PixProvider (placeholder até PSP real)
  ├── KYC Module ──► KycProvider (sandbox até provedor real)
  ├── Webhooks Module (Pix / Off-ramp / KYC — assinatura + idempotência)
  ├── Admin Module (dashboard, usuários, integrações, auditoria)
  ├── Audit Module (log central de ações sensíveis)
  └── Notifications Module (stub até provedor de e-mail/push real)
  │
  ▼
PostgreSQL (Prisma) + Redis (cache/rate limiting)
```

## Decisão: monólito modular, não microsserviços

O diagrama original da especificação sugere serviços separados (Wallet
Service, Pricing Service, Transaction Service, Conversion Service). Na v1,
todos esses "serviços" são módulos NestJS dentro da mesma API — a separação
lógica (interfaces, DTOs, responsabilidades) é idêntica à de microsserviços,
mas sem o custo operacional de orquestrar múltiplos deploys, filas entre
serviços e observabilidade distribuída antes que o volume de uso justifique
isso. Cada módulo já depende apenas de interfaces (`BlockchainProvider`,
`PricingProvider`, `OffRampProvider`, `PixProvider`, `KycProvider`), então
extrair qualquer um deles para um serviço próprio no futuro é uma mudança de
infraestrutura, não de design.

## Padrão de Adapters

Toda integração externa (blockchain, cotação, off-ramp, Pix, KYC) é acessada
через uma interface própria (`*-provider.interface.ts`), nunca diretamente.
Isso permite:
- Trocar de provedor sem alterar o restante do sistema.
- Ter adapters "placeholder" que lançam erro explícito em vez de simular
  dados — nenhuma integração real é fingida.
- Testar a lógica de negócio isoladamente (mockando a interface).

## Máquina de estados da venda

```
CREATED → QUOTED → AWAITING_USER_AUTHORIZATION → AUTHORIZED → BROADCASTED
  → CONFIRMING → CONFIRMED → CONVERTING → BRL_AVAILABLE → PIX_PENDING
  → PIX_PROCESSING → COMPLETED
```
Cada seta é a única transição válida a partir do estado anterior
(`VALID_TRANSITIONS` em `sell-order.service.ts`). Não é possível pular
etapas de confirmação — testado em `sell-order.service.spec.ts`.

## O que falta para produção real

- Provedores reais de KYC, Off-ramp e Pix (ver `docs/kyc.md`,
  `docs/payments.md`, `docs/pix.md`).
- Fila (ex: BullMQ sobre Redis) para processar webhooks de forma assíncrona
  e resiliente em vez de processá-los sincronamente na requisição HTTP.
- Em volume alto, substituir o polling do `IndexerService` (seção abaixo)
  por webhooks nativos de confirmação (ex: Alchemy Notify) ou por uma fila
  com jobs agendados por transação.

## Worker de indexação de blockchain

`apps/api/src/modules/indexer/indexer.service.ts` faz polling periódico
(`@Interval`, padrão 30s, configurável via `INDEXER_POLL_INTERVAL_MS`) de
todas as `SellOrder` em `BROADCASTED`/`CONFIRMING`, consulta a blockchain
real via `WalletService.getTransactionConfirmations` e avança a máquina de
estados de forma incremental:
- confirmações parciais (>0, abaixo do mínimo) → `CONFIRMING`
- confirmações suficientes (mínimo por rede, ex: 3 para Bitcoin, 12 para
  Ethereum — ver `DEFAULT_REQUIRED_CONFIRMATIONS`) → `CONFIRMED` →
  `CONVERTING`, disparando a criação da ordem no parceiro de off-ramp

Falhas de RPC/blockchain não marcam a ordem como `FAILED` automaticamente
(evita falsos positivos por instabilidade temporária) — apenas logam e
tentam de novo no próximo ciclo. Testado em
`sell-order.advance.spec.ts` (4 cenários: sem confirmação, confirmação
parcial, confirmação completa + chamada ao off-ramp, e ordem já avançada
por outro caminho).
