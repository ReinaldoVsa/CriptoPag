# Carteiras — CryptoPay

Fluxo (seção 10 da especificação original):
Selecionar blockchain → inserir endereço (manual, QR Code ou WalletConnect)
→ validar formato → consultar blockchain → salvar somente o endereço público.

- Endpoint de validação: `POST /api/v1/wallets/validate`
- Endpoint de cadastro: `POST /api/v1/wallets`
- Saldo: `GET /api/v1/wallets/:id/balance` (consulta ao vivo na blockchain +
  cotação atual, nunca cacheado além de 15s no lado da cotação)

## WalletConnect
O frontend (`apps/web`) inclui as dependências `@walletconnect/modal` e
`@walletconnect/sign-client` no `package.json`, mas a integração de UI (modal
de conexão, assinatura de transação) ainda precisa ser implementada com um
`NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` real — sem um Project ID válido do
WalletConnect Cloud, a conexão não funciona.

## Leitor de QR Code
`html5-qrcode` já está no `package.json` do frontend. O componente de leitura
deve ser client-only (usa câmera do navegador/dispositivo) e chamar o mesmo
endpoint `POST /wallets` após decodificar o endereço.
