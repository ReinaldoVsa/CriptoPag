# Segurança — CryptoPay

## Autenticação
- Access token JWT de curta duração (15 min por padrão), assinado com
  `AUTH_SECRET`.
- Refresh token opaco (256 bits), armazenado com hash SHA-256 no banco,
  entregue ao cliente em cookie `HttpOnly`, `SameSite=Lax`, `Secure` em
  produção. Rotação a cada uso (o token antigo é revogado).
- Senhas com hash `bcrypt` (12 rounds).

## RBAC
Papéis `USER` / `ADMIN` / `SUPER_ADMIN`. Rotas administrativas protegidas por
`@Roles(...)` + `RolesGuard`.

## Rate limiting
`@nestjs/throttler` global (100 req/min por IP) + limites mais restritos em
endpoints sensíveis (`/auth/register`, `/auth/login`, `/auth/forgot-password`).

## Webhooks
Toda assinatura é validada via HMAC-SHA256 com `crypto.timingSafeEqual`
(evita timing attacks) contra o secret específico de cada integração
(`PIX_WEBHOOK_SECRET`, `OFFRAMP_WEBHOOK_SECRET`, `KYC_WEBHOOK_SECRET`).
Eventos sem assinatura válida são rejeitados e registrados como `FAILED` em
`WebhookEvent` — nunca processados.

## Nunca custodial
O sistema nunca solicita, recebe ou armazena seed phrase ou chave privada.
Apenas endereços públicos são persistidos. Autorização de transações
acontece via WalletConnect (assinatura acontece na carteira do usuário,
fora do CryptoPay).

## Secrets
- Nunca commitados: `.gitignore` cobre `.env*`.
- No painel admin (`/admin/integrations`), API keys e secrets são
  mascarados — o schema `Integration` só guarda `apiKeyMasked` e um booleano
  `hasSecret`, nunca o valor real.
- No Netlify, apenas variáveis `NEXT_PUBLIC_*` — nenhum secret de backend.

## Cabeçalhos HTTP
`helmet()` aplicado globalmente na API.

## O que ainda precisa ser adicionado antes de produção
- Auditoria de segurança externa (pentest) antes de operar com fundos reais.
- MFA (campo `mfaEnabled`/`mfaSecret` já existe no schema, fluxo de
  configuração ainda não implementado no frontend).
- Fila assíncrona para processamento de webhooks (hoje síncrono).
