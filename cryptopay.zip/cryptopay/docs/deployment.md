# Deploy — CryptoPay

## Frontend/PWA — Netlify
1. Conectar o repositório GitHub ao Netlify.
2. Build command e publish directory já estão em `netlify.toml`
   (`apps/web`, plugin `@netlify/plugin-nextjs`).
3. Configurar variáveis de ambiente no Netlify (apenas públicas):
   `NEXT_PUBLIC_API_URL`, `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID`,
   `NEXT_PUBLIC_APP_URL`.
4. Nunca configurar `DATABASE_URL`, `*_SECRET`, `*_API_KEY` de backend no
   Netlify — o frontend não deve ter acesso a esses valores.

## Backend — Cloud/VPS
O `Dockerfile` na raiz builda a API como imagem standalone. Opções
possíveis: Render, Railway, Fly.io, AWS, Google Cloud, Azure, VPS próprio.
Nenhuma dessas contas foi provisionada — escolha uma, configure as variáveis
de ambiente de `.env.example` no painel do provedor e aponte o deploy para
este `Dockerfile`.

## Banco de dados
Use um PostgreSQL gerenciado (ex: Supabase, Neon, Railway, RDS, Cloud SQL).
Configure backup automático e retenção antes de qualquer dado real.

## Domínio
`cryptopay.com.br` é um exemplo — nenhum domínio foi verificado ou
registrado por este processo. Configure DNS + HTTPS/SSL apontando para o
Netlify (frontend) e para o backend (subdomínio `api.`) somente após
adquirir e verificar o domínio real.

## Checklist antes de publicar
Ver `README.md` — seção "Checklist de produção", que reflete a checklist
original da especificação.
