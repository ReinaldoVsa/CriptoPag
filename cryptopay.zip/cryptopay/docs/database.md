# Banco de dados — CryptoPay

PostgreSQL via Prisma. Schema completo em `apps/api/prisma/schema.prisma`.

## Entidades principais
`User`, `UserProfile`, `RefreshToken`, `Wallet`, `WalletAsset`,
`BlockchainTransaction`, `Quote`, `SellOrder`, `PixPayment`,
`KycVerification`, `WebhookEvent`, `Integration`, `AuditLog`, `Notification`.

## Comandos

```bash
npm run prisma:generate   # gera o client TypeScript a partir do schema
npm run prisma:migrate    # cria/aplica migration em desenvolvimento
npm run prisma:seed       # popula admin de exemplo + integrações placeholder
```

Em produção, use `prisma migrate deploy` (nunca `migrate dev`) e nunca rode
migrations destrutivas automaticamente — revise o SQL gerado antes de aplicar
em uma base com dados reais.

## Índices e constraints relevantes
- `Wallet` possui unique composto `(userId, address, network)` — evita
  duplicar a mesma carteira para o mesmo usuário.
- `SellOrder.idempotencyKey` e `PixPayment.idempotencyKey` são únicos —
  garante que retries não dupliquem operações financeiras.
- `WebhookEvent` possui unique composto `(source, externalEventId)` — evita
  reprocessar o mesmo evento de webhook duas vezes.
