# Conversão Cripto → BRL (Off-Ramp) — CryptoPay

Interface: `apps/api/src/modules/sell-order/offramp-provider.interface.ts`.

**Nenhum parceiro de off-ramp está integrado.** O adapter atual
(`OffRampPlaceholderProvider`) lança erro explícito em qualquer chamada —
isso é intencional: a especificação original proíbe inventar parceiros
financeiros.

## Para integrar um parceiro real
1. Escolher um parceiro de off-ramp licenciado para operar no Brasil.
2. Implementar `OffRampProvider` com o SDK/API oficial dele.
3. Configurar `OFFRAMP_PROVIDER`, `OFFRAMP_API_URL`, `OFFRAMP_API_KEY`,
   `OFFRAMP_API_SECRET`, `OFFRAMP_WEBHOOK_SECRET` em `.env`.
4. Trocar o provider injetado em `SellOrderModule`.
5. Validar em sandbox do parceiro antes de qualquer teste com valores reais.
