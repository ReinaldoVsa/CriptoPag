# Setup local — CryptoPay

## Requisitos
- Node.js 20+
- Docker e Docker Compose
- npm 10+

## Passo a passo

1. Clonar o repositório e instalar dependências (raiz do monorepo):
   ```bash
   npm install
   ```

2. Copiar variáveis de ambiente:
   ```bash
   cp .env.example .env
   ```
   Preencha ao menos `AUTH_SECRET` (qualquer string aleatória longa) para
   desenvolvimento. As demais (`BLOCKCYPHER_API_KEY`, `ALCHEMY_API_KEY`,
   `WALLETCONNECT_PROJECT_ID`, `OFFRAMP_*`, `PIX_*`, `KYC_*`) só são
   necessárias quando for testar a integração real correspondente.

3. Subir Postgres e Redis:
   ```bash
   docker compose up -d postgres redis
   ```

4. Gerar o Prisma Client e rodar as migrations:
   ```bash
   npm run prisma:generate
   npm run prisma:migrate
   npm run prisma:seed
   ```

5. Rodar a API e o frontend (dois terminais):
   ```bash
   npm run dev:api   # http://localhost:3001 (docs em /docs)
   npm run dev:web   # http://localhost:3000
   ```

6. Login de exemplo criado pelo seed: `admin@cryptopay.com.br` /
   `ChangeMe123!` (troque a senha imediatamente, é apenas para desenvolvimento).

## Rodando tudo via Docker Compose

```bash
docker compose up -d --build
```
Sobe Postgres, Redis, API (porta 3001) e Web (porta 3000).
