# API — Referência rápida

Documentação interativa completa (Swagger/OpenAPI) disponível em
`GET /docs` quando a API estiver rodando (ex: http://localhost:3001/docs).

Todas as rotas abaixo têm prefixo `/api/v1`, exceto `/health` e `/ready`.

| Método | Rota | Auth | Descrição |
|---|---|---|---|
| POST | /auth/register | não | Cadastro |
| POST | /auth/login | não | Login |
| POST | /auth/refresh | cookie | Renova access token |
| POST | /auth/logout | JWT | Encerra sessão |
| POST | /auth/forgot-password | não | Recuperação de senha |
| GET | /users/me | JWT | Perfil do usuário |
| POST | /wallets/validate | JWT | Valida endereço para uma rede |
| POST | /wallets | JWT | Adiciona carteira |
| GET | /wallets | JWT | Lista carteiras do usuário |
| GET | /wallets/:id/balance | JWT | Saldo + valor estimado em BRL |
| GET | /wallets/:id/transactions | JWT | Transações on-chain da carteira |
| GET | /assets | JWT | Ativos suportados |
| GET | /prices/:asset | JWT | Cotação atual |
| POST | /quotes | JWT | Cria cotação temporária de venda |
| GET | /quotes/:id | JWT | Consulta cotação |
| POST | /sell-orders | JWT | Cria ordem de venda a partir de uma cotação |
| POST | /sell-orders/:id/authorize | JWT | Registra autorização (txHash) |
| GET | /sell-orders/:id | JWT | Consulta ordem de venda |
| GET | /transactions | JWT | Histórico do usuário |
| POST | /pix/payments | JWT | Cria pagamento Pix para uma ordem BRL_AVAILABLE |
| GET | /pix/payments/:id | JWT | Consulta pagamento Pix |
| POST | /kyc/start | JWT | Inicia verificação KYC |
| GET | /kyc/status | JWT | Status da verificação |
| POST | /webhooks/pix | assinatura HMAC | Webhook do PSP |
| POST | /webhooks/offramp | assinatura HMAC | Webhook do parceiro off-ramp |
| POST | /webhooks/kyc | assinatura HMAC | Webhook do provedor KYC |
| GET | /admin/dashboard | JWT + RBAC | Métricas administrativas |
| GET | /admin/users | JWT + RBAC | Lista de usuários (paginada, buscável) |
| GET | /admin/integrations | JWT + RBAC | Status das integrações (secrets mascarados) |
| GET | /admin/audit-logs | JWT + RBAC | Log de auditoria (paginado) |
| GET | /admin/webhooks | JWT + RBAC | Eventos de webhook recebidos |
| GET | /health | não | Liveness |
| GET | /ready | não | Readiness (checa banco) |
