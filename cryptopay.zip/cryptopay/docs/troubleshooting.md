# Troubleshooting — CryptoPay

**`prisma generate` falha com erro de rede/checksum**
Ambiente sem acesso a `binaries.prisma.sh`. Rode em uma máquina/CI com
acesso irrestrito à internet, ou configure um mirror interno dos engines do
Prisma.

**`ServiceUnavailableException: BLOCKCYPHER_API_KEY não configurada`**
Configure a variável em `.env` — sem ela, consultas a endereços Bitcoin
falham propositalmente (nunca retornamos saldo simulado).

**`Nenhum PSP de Pix configurado` / `Nenhum parceiro de off-ramp configurado`**
Esperado até que você integre um parceiro real (ver `docs/pix.md` e
`docs/payments.md`). Esses módulos são funcionais em toda a lógica de
orquestração, mas dependem de um adapter real para operar de fato.

**Webhook retorna 400 "Assinatura inválida"**
Confira se o secret configurado (`PIX_WEBHOOK_SECRET`, etc.) é exatamente o
mesmo configurado no painel do parceiro, e se o corpo da requisição não está
sendo alterado por um proxy/gateway antes de chegar à API (a assinatura é
calculada sobre o corpo bruto/raw, `rawBody`).

**`docker compose up` falha na API por não conseguir conectar ao Postgres**
O serviço `api` depende de `postgres` e `redis` com healthcheck
(`depends_on: condition: service_healthy`) — aguarde os healthchecks
passarem antes de assumir falha real; confira `docker compose logs postgres`.
