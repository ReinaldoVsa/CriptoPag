# Blockchain — CryptoPay

Interface comum: `apps/api/src/modules/wallet/blockchain-provider.interface.ts`.

| Rede | Provider | Requer |
|---|---|---|
| Bitcoin | `BlockCypherProvider` | `BLOCKCYPHER_API_KEY` |
| Ethereum | `AlchemyProvider` | `ALCHEMY_API_KEY` |
| Polygon / BSC / Arbitrum | `RpcProvider` | `RPC_URL_POLYGON` / `RPC_URL_BSC` / `RPC_URL_ARBITRUM` |

Todos os adapters lançam `ServiceUnavailableException` explícita se a
credencial correspondente não estiver configurada — nunca retornam saldo
zero ou simulado.

## Adicionando uma nova rede
1. Implemente `BlockchainProvider` para a rede.
2. Registre a instância em `WalletService.providers` (mapa `network -> provider`).
3. Adicione o valor ao enum `BlockchainNetwork` no `schema.prisma` e rode uma
   migration.
