# KYC/AML — CryptoPay

Interface: `apps/api/src/modules/kyc/kyc-provider.interface.ts`.

O adapter atual (`SandboxKycProvider`) existe apenas para desenvolvimento:
todo pedido de verificação fica em `IN_REVIEW` indefinidamente e o provider
**lança erro se `NODE_ENV=production`** — isso impede que "KYC fictício"
chegue a produção por engano.

## Status possíveis
`PENDING`, `IN_REVIEW`, `APPROVED`, `REJECTED`, `REQUIRES_REVIEW`.

## Para integrar um provedor real
1. Escolher um provedor de KYC/AML (verificação de identidade, checagem de
   listas de sanções, monitoramento de transações).
2. Implementar `KycProvider` com a API oficial dele.
3. Configurar `KYC_PROVIDER`, `KYC_API_KEY`, `KYC_API_SECRET`,
   `KYC_WEBHOOK_SECRET` em `.env`.
4. Trocar o provider injetado em `KycModule`.
5. Implementar `POST /webhooks/kyc` de ponta a ponta com o formato de evento
   real do provedor (o `WebhooksService.handleKycWebhook` atual assume um
   payload genérico `{ verificationId, status, reason }` que deve ser
   adaptado ao provedor escolhido).
