# scripts/

Reservado para scripts operacionais (ex: rotação de secrets, backup manual
de banco, importação de dados). Vazio nesta versão.
