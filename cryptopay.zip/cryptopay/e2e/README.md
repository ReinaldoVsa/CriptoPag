# e2e/

Reservado para testes end-to-end com Playwright cobrindo o fluxo completo
(Cadastro → Login → KYC → Adicionar carteira → Consultar saldo → Quote →
Venda → Conversão → Pix → Confirmação — seção 35 da especificação
original). Requer os adapters reais (ou mocks de sandbox dos parceiros)
configurados para rodar de ponta a ponta; não implementado nesta versão por
depender de credenciais de sandbox de parceiros ainda não contratados.
